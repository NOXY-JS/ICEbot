"use strict";

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
	if (message.action.indexOf("join")!=-1) {
		                let room=message.action.split("join.")[1]

   fetch("https://gartic.io/server?check=1&v3=1&room="+room).then(x=>x.text()).then(x=>{
            let ws=new WebSocket("wss://"+x.split("https://")[1].split(".")[0]+".gartic.io/socket.io/?c="+x.split("?c=")[1]+"&EIO=3&transport=websocket"); ws.onopen=()=>{
            	  ws.send('42[3,{"v":20000,"nick":"ICEbot'+Math.ceil(Math.random()*10000+1)+'","avatar":1,"platform":0,"sala":"'+room.substring(2)+'"}]')
            	}})
   sendResponse({ response: "Mensagem 'runContentScript' recebida com sucesso na aba" });
  }

  if (message.message === "teste") {

    console.log("Mensagem 'teste' recebida na aba: ", sender.tab.id);

    sendResponse({ response: "Mensagem 'teste' recebida com sucesso na aba" });
  }
  return true;
});