"use strict";
function LUNA_(...v){
  let obj = [];obj = obj.concat(v, Math.random() * 10000);chrome.storage.local.set({message: JSON.stringify(obj)});
}
function __0x70(...a){
  let o= [];o = o.concat(a);window.postMessage('cmd.'+JSON.stringify(o), '*');
}
function __0x11(...a){
  let o= [];o = o.concat(a);document.querySelectorAll('iframe').forEach(function(c) {c.contentWindow.postMessage('cmd.'+JSON.stringify(o), '*');
});
}

function __0x52(...a){console.log(a[1]);
  let o= [];o = a.slice(0, 1).concat(a.slice(2));document.querySelectorAll('iframe').forEach(function(c) {if(c.src.includes(a[1])){c.contentWindow.postMessage('cmd.'+JSON.stringify(o), '*');
}});
}
function f(ICE){return document.querySelector(ICE)}
function fa(ICE){return document.querySelectorAll(ICE)}

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}


    function addStyle(css) {
      const style = document.createElement('style');
      style.textContent = css;
      document.documentElement.appendChild(style);
    };

    function addHtml(html) {
      document.documentElement.insertAdjacentHTML('beforeend', html);
    }
    function setmenu(menu){const elements=['#icebot1','#icebot2','#icebot3','#icebot4',"#icebot5","#icebot6","#icebot7","#icebot8",'#avatarlist'];elements.forEach(element=>{if(element===`#${menu}`){document.querySelector(element).style.display='block';}else{document.querySelector(element).style.display='none';}})};
    let cmd="",wss=[],tojoin=0,usersinroom=[],customkickitems=[],messagejoinitems=[],tfr,tg,intervalbroadcast,intervalmsg,intervalanswer,intervalantiafk,rainbowdraw,rainbowdrawmode=false,botsidvalue=[],wordsInterval,wordsIntervalPlayer,botID,botlongID,theme,tipo,idioma,am,avatar=localStorage.getItem("avatar"),botnick=localStorage.getItem("botnick"),nick=localStorage.getItem("nick")
    

let FoodsPt = [ "Arroz", "Feijão", "Macarrão", "Batata", "Coxa de frango", "Carne de boi", "Peixe", "Ovo", "Queijo", "Presunto", "Alface", "Tomate", "Cenoura", "Beterraba", "Brócolis", "Couve-flor", "Abóbora", "Abobrinha", "Cebola", "Pimentão", "Pepino", "Morango", "Banana", "Maçã", "Laranja", "Mamão", "Melancia", "Melão", "Uva", "Manga", "Kiwi", "Abacaxi", "Pêra", "Limão", "Pêssego", "Ameixa", "Damasco", "Amêndoa", "Nozes", "Castanha", "Amendoim", "Pipoca", "Sorvete", "Iogurte", "Leite", "Manteiga", "Azeite", "Vinagre", "Açúcar", "Sal", "Pimenta", "Orégano", "Salsinha", "Cebolinha", "Erva-doce", "Manjericão", "Alecrim", "Pão", "Bolacha", "Bolo", "Torta", "Brigadeiro", "Pudim", "Gelatina", "Mousse", "Brownie", "Biscoito", "Sushi", "Sashimi", "Tempurá", "Yakisoba", "Ramen", "Udon", "Soba", "Niguiri", "Temaki", "Gyoza", "Harumaki", "Shimeji", "Shiitake", "Champignon", "Aspargo", "Alcachofra", "Acelga", "Agrião", "Alga", "Lentilha", "Grão-de-bico", "Amaranto", "Quinoa", "Chia", "Linhaça", "Aveia", "Trigo", "Centeio", "Milho", "Soja", "Cará", "Inhame", "Nabo", "Rabanete", "Alcachofra", "Ostra", "Mexilhão", "Salmão", "Atum", "Bacalhau", "Linguado", "Robalo", "Sardinha", "Truta", "Tilápia", "Tambaqui", "Pirarucu", "Dourado", "Agulha", "Bagre", "Pintado", "Carpa", "Tambacu", "Javali", "Coelho", "Codorna", "Pato", "Marreco", "Peru", "Ganso", "Faisão", "Avestruz", "Vison", "Jacaré", "Tartaruga", "Cervo", "Veado", "Pomba", "Pombo", "Camarão", "Lagosta", "Siri", "Caranguejo", "Polvo", "Lula", "Mexilhão", "Ostra" ];
let FoodsTr= [ "tulumba", "findık ekmesi", "kavurma", "hamburger", "fıstık", "fanta", "kola", "çekirdek", "yumurta", "but", "midye", "ekler", "cips", "kayısı", "lahmacun", "dürüm", "kavun", "karbur", "Supangle", "kokoreç", "olips", "tost", "kadayıf", "Avokado", "Pizza", "dondurma", "çiğ köfte", "pakek", "kazandibi", "süt", "bazlama", "şeftali", "nektari", "Falım", "Çikolata", "Bonfile", "şwker", "pide", "ekmek", "ayran", "meyve suyu", "puding", "vişne", "elma", "fındık", "fındık ezmesi", "kek", "et", "lolipop", "kanat", "limonata", "patates kızartaması", "traliçe", "baklava", "bonfile" ]
let MinecraftPt = [ "peixe", "madeira", "arvore", "alex", "porco", "arco", "gato", "machado", "enderman", "baú", "vara de pescar", "poção", "abóbora", "balde de lava", "ovelha", "grama", "balde de leite", "ouro", "areia", "porco zumbi", "cavalo", "pão", "galinha", "ferro", "enxada", "maçã dourada", "bolo", "slime", "bola de neve", "warden", "espada de ferro", "graveto", "cascalho", "steve", "ender dragon", "melancia", "aldeão", "poção arremesável", "wither", "pérola do End", "cenoura", "enxada de diamante", "pólvora", "diamante", "pena", "semente de trigo", "carvão", "redstone", "TNT", "sela", "lágrima de Ghast", "esqueleto", "aranha", "lula", "zombie pigman", "blaze", "endermite", "lobo", "vaca", "coelho", "morcego", "flor", "maçã", "axolote" ]
let ObjectsPt = [ "mouse pad", "machado", "panela de pressão", "piano", "agulha", "chocalho", "chinelo", "poncheira", "cotoveleira", "dado", "armadura", "estilingue", "caldeirão", "cachepô", "berimbau", "carrinho de rolimã", "ferrolho", "cetro", "sanfona", "conga", "guarda-sol", "escova de dente", "varal", "borrifador", "chaleira", "mimeógrafo", "rodo", "serpentina", "caixa de ferramentas", "pires", "rastelo", "chave de grifo", "betoneira", "estatueta do oscar", "fones de ouvido", "bandana", "monóculo", "navalha", "enxada", "serra elétrica", "gangorra", "broca", "ganzá", "sombrero", "telha", "charango", "biombo", "órgão", "miçanga", "saxofone", "bola de gude", "lustre", "pochete", "monitor", "retroprojetor", "marionete", "patinete", "chip" ]
let FootballPt = [ "juventude", "ituano", "sertãozinho", "tigres", "newcastle", "metalist", "uberaba", "ajax", "olympiacos", "manchester united", "barcelona", "campo grande", "brasil de pelotas", "argentinos juniors", "benfica", "bayern de munique", "cuiabá", "getafe", "napoli", "paranavaí", "racing", "athletico paranaense", "confiança", "união são joão", "brasiliense", "monte azul", "everton", "joinville", "gaúcho", "corinthians", "lanús", "swansea city", "ypiranga", "entrerriense", "athletic bilbao", "fiorentina", "mirassol", "anapolina", "remo", "csa", "boa esporte", "penedense", "chivas", "camaçari", "icasa", "bom sucesso", "once caldas", "stuttgart", "vélez sarsfield", "friburguense", "levante", "málaga", "ituiutaba", "sampaio corrêa", "estudiantes", "cascavel", "mogi mirim", "siena", "aston villa", "independiente", "universidad de chile", "tottenham", "real sociedad", "real zaragoza", "bangu", "ldu", "murici", "manchester city", "macaé", "paulista", "vitória", "ponte preta", "vera cruz", "lille", "linense", "democrata", "inter de milão", "operário", "stoke city", "americano", "vila aurora", "central", "peñarol", "bordeaux", "wolfsburg", "noroeste", "juventus", "chapecoense", "morelia", "panathinaikos", "basel", "atalanta", "volta redonda", "chelsea", "santo andré" ]
let FlagsPt = [ "barbados", "camarões", "congo", "samoa", "croácia", "ilhas marshall", "maldivas", "gâmbia", "canadá", "uruguai", "san marino", "jordânia", "reino unido", "lituânia", "áustria", "islândia", "irã", "hungria", "bolívia", "trinidad e tobago", "afeganistão", "cuba", "guiné-bissau", "comores", "mongólia", "cingapura", "bélgica", "zâmbia", "romênia", "chade", "malauí", "paquistão", "etiópia", "timor-leste", "camboja", "síria", "ilhas salomão", "cazaquistão", "quênia", "omã", "argélia", "tanzânia", "méxico", "nepal", "brasil", "chile", "jamaica", "vanuatu", "lesoto", "luxemburgo", "guiné", "santa lúcia", "chipre", "fiji", "dominica", "laos", "eritreia", "belarus", "costa rica", "argentina", "zimbábue", "malta", "bulgária", "papua nova guiné", "holanda", "eslovênia", "mônaco", "turquia", "brunei", "emirados árabes unidos", "tunísia", "mali", "guiné-equatorial", "noruega", "barein", "colômbia", "nauru", "coreia do sul", "coreia do norte", "marrocos", "montenegro", "suíça", "burundi", "egito", "paraguai", "costa do marfim" ]
let GeneralPt = [ "sal grosso", "abafador", "diarista", "barrigudo", "alicate", "elmo", "vatapá", "milho", "pipoca doce", "paraquedas", "assistir", "cavalete", "enxaguar", "lacrimejar", "cereal", "vinho branco", "baleiro", "delineador", "fortalecer", "rosário", "beterraba", "alisar", "amigo", "passeata", "bugio-preto", "bifurcar", "fofocar", "cortador de grama", "doce de leite", "quartel", "abduzir", "corvina", "prender", "macadâmia", "biombo", "batom", "cuco", "comparar", "sorvete napolitano", "bombardear", "skate", "desfilar", "estrela-do-mar", "temperar", "bloquear", "teatro", "granizo", "aerofólio", "churrasco", "coxa de frango", "guirlanda", "bolo", "fatiar", "espada", "trompete", "petit gateau", "afastado", "artéria", "invejoso", "roer", "marceneiro", "internet", "protetor bucal", "acinturado", "estacionamento", "joelho", "linha", "adiantado", "juiz", "digerir", "comediante", "rabanete", "abarrotado", "quieto", "disquete", "salpicão", "cabecear", "lacrar", "furgão", "ourives", "guiar", "ratoeira", "mina", "polaina", "grande", "suco de goiaba", "figo", "bocal", "piranha", "óculos", "ciclismo", "carvão", "costeleta", "rebanho", "doméstica", "colorido", "intestino", "tanque", "átomo", "banheiro", "ferreiro", "alagar", "decorador", "esterilizador", "coroa", "faquir", "encadernador", "aveia", "jabuticaba", "maquiador", "doce de abóbora", "orar", "piorar", "portão", "relicário", "quinoa", "rasurar", "pé de pato", "bambu", "ornitorrinco", "barbante", "gaúcho", "aspargo" ]
let LogosPt = [ "mastercard", "instagram", "lg", "nike", "apple", "deezer", "santander", "abril", "mercedes-benz", "bmw", "hello kitty", "chevrolet", "domino's", "waze", "mercado livre", "microsoft", "reddit", "rolex", "peugeot", "volkswagen", "hering", "bic", "mitsubishi", "pringles", "natura", "carrefour", "hsbc", "adidas", "chanel", "lacoste", "kibon", "firefox", "audi", "android", "shell", "kfc", "bradesco", "pepsi", "banco do brasil", "toyota", "dove", "linux", "whatsapp", "adobe", "mcdonald's", "playstation", "globo", "starbucks", "atari", "spotify", "ferrari", "uol", "toblerone", "puma", "the rolling stones", "motorola", "tesla", "burger king", "google chrome", "dreamworks", "redbull", "twitter" ]
let AnimesPt = [ "king", "kankuro", "izuku midoriya", "sarada uchiha", "squirtle", "diane", "minato", "kakegurui", "noragami", "another", "kakuzu", "dabi", "sailor moon", "zenitsu agatsuma", "mikasa ackerman", "rasengan", "luffy", "asta", "darling in the franxx", "yakusoku no neverland", "norman", "gon freecss", "boruto", "zetsu", "tobirama senju", "barba branca", "death parade", "madara", "goku", "goten", "all might", "tsuyu asui", "bulma", "beyblade", "estarossa", "naruto shippuden", "yu-gi-oh", "konan", "samurai x", "tate no yuusha", "mirai nikki", "death note", "trunks", "pikachu", "made in abyss", "shanks", "cavaleiros do zodíaco", "kushina uzumaki", "natsu dragneel", "silver chariot", "elfen lied", "code geass", "shokugeki no souma", "jojo", "sonic", "armin arlert", "choji akimichi", "jiraya", "sorahiko torino", "zero two", "tony tony chopper", "neon genesis evangelion", "danganronpa", "assassination classroom", "dororo", "fumikage tokoyami", "aerosmith", "fate", "gold experience", "karin uzumaki", "rukia kuchiki", "mob psycho 100", "eri", "charizard", "broly", "hinata", "gohan", "nanatsu no taizai", "tomura shigaraki", "durarara", "kabuto yakushi", "ajin", "vinsmoke sanji", "yato", "narancia ghirga", "koe no katachi", "charlotte", "highschool of the dead", "kirito", "emma", "akira", "bakugan", "freeza" ]
let FoodsEn2 = [ "rice", "soda", "lemongrass", "dosa", "caramel", "mustard", "nugget", "yogurt", "samosa", "pretzel", "sprite", "salad", "crab", "rosemary", "chocolate", "pomegranate", "baguette", "melon", "dorayaki", "marshmallow", "sweet potato", "brownies", "cinnamon", "oats", "jelly", "coca cola", "mint", "lemon", "pineapple", "lemonade", "tuna", "sugar", "pizza", "mushroom", "tofu", "hazelnut", "fish cake", "waffle", "almond", "peanut butter", "cheese", "guava", "grilled fish", "burrito", "maple syrup", "sour cream", "popcorn", "spaghetti", "smoothie", "cocktail", "lettuce", "cake", "cotton candy", "blueberry", "coconut milk", "meat ball", "vanilla", "sashimi", "plum", "cereal", "shrimp", "curry", "capsicum", "pancake", "crepe", "cauliflower", "mashed potato", "green tea", "fruit cake", "flan", "steak", "biscuit", "peas", "pepper", "pumpkin", "broccoli", "papaya", "star fruit", "noodles", "skittles", "jack fruit", "grape", "watermelon", "croissant", "orange", "salt", "macaroons", "peach", "avocado", "chicken leg", "raisins", "fanta", "cherry", "kebab", "juice", "octopus", "gravy", "tomato", "pani puri", "apple", "garlic", "beer", "ketchup", "cucumber" ];let words=[]
let CartoonsPt=["os backyardigans","vegeta","pocoyo","elsa","bela","patrulha canina","naruto","puro osso","corrida maluca","olaf","super choque","as aventuras de jackie chan","barney","dick vigarista","jasper","stitch","up altas aventuras","garfield","du dudu e edu","plankton","homer simpson","winx","patrick estrela","meu malvado favorito","rei leão","cebolinha","zé colmeia","os jetsons","minnie mouse","looney tunes","diamante azul","sailor moon","jasmine","mulher maravilha","hércules","lilo","capitão gancho","galinha pintadinha","dexter","fiona","shrek","mordecai","hello kitty","madagascar","ratatouille","bambi","taz","caverna do dragão","pokémon","homem de ferro","enrolados","a pequena sereia","aurora","marge simpson","irmão do jorel","clarêncio","sakura haruno","cinderela","piu piu","divertidamente","darwin watterson","mogli","dora aventureira","as meninas superpoderosas","luluzinha","goku","samurai jack","pumba","wall-e","simba","tutubarão","flash","wanda","ben 10","os jovens titãs","velma","mabel pines","ursinhos carinhosos","princesa caroço","os flintstones","kim possible","juniper lee","coringa","nemo","jake","detona ralph","inspetor bugiganga","johnny test","buzz lightyear","dumbo","tartarugas ninjas","tarzan","moranguinho","pateta","branca de neve","bart simpson","101 dálmatas","ariel","robin","zootopia","my little pony","death note","snoopy","pucca","o laboratório de dexter","flapjack","docinho","gravity falls","apenas um show","doug funnie","garnet","o máscara","patolino","rick and morty","connie maheswaran","moana","estelar","liga da justiça","charlie brown","ligeirinho","hora de aventura","tom","ametista","dragon ball z","pluto","homem-aranha","frajola","ravena","bob esponja","frozen","kung fu panda","aladdin","anna","she-ra","carros","mônica","woody","o incrível mundo de gumball"]
let FoodsEn = ["grape","pepper","bell pepper","beer","pie","nutella","wheat","sour cream","frosting","cauliflower","ketchup","paprika","cabbage","mayonnaise","caramel","oyster","hotdog","nugget","milkshake","cheese cake","cloves","beans","watermelon","potato","fries","cookie","eggplant","octopus","sugar","omelette","steak","biryani","hazel nut","coconut milk","salmon","lasagna","oats","papaya","dosa","boba tea","dorayaki","croissant","yogurt","fanta","strawberry","popcorn","milk","green tea","doritos","pani puri","meat ball","raspberry","cereal","almond","tofu","ginger","carrot","peas","fish cake","chilli","bibimbap","cake","mint","roast chicken","sausage","crepe","banana","kebab","star fruit","mashed potato","lettuce","crab","black tea","cotton candy","fruit cake","noodles","salt","corndog","tacos","mushroom","tomato","honey","chocolate","donut","beetroot","muffin","bagel","sweet potato","avocado","pear","sashimi","sushi","peach","pudding","maple syrup","oatmeal","cream","apple","gravy","bacon","kiwi","curry","corn dog","radish","juice","chicken leg","lychee","corn","tuna","pumpkin","oreo","ice","ravioli","jack fruit","melon","biscuit","ham","pasta","kimchi","porridge","butter","cinnamon","dumplings","spinach","bay leaf","marshmallow","shrimp","lobster","macaroons","vodka","jam","rice","sprite","vanilla","beef","egg","pizza","grilled fish","wine","lemongrass","baguette","peanut butter","plum","cocktail","bread","grilled chicken","brownies","water","blueberry","orange","smoothie","coca cola","lava cake","soup","lemon","pocky","milk tea","spaghetti","pretzel","flan","cheese"]
        if(window.location.href.indexOf("gartic.io")!=-1){
        	   let ws__=new WebSocket('ws://localhost:8081');
let red=["#cc0010","#a3000c","#820009","#680007","#530005","#FFFFFF"],orange=["#cc5b00","#a34800","#FFA500","#682d00","#532400","#FFFFFF"],yellow=["#ccbf00","#a39800","#FFFF00","#686000","#534c00","#000000"],green=["#66cc00","#51a300","#408200","#336800","#285300","#FFFFFF"],blue=["#2100cc","#1a00a3","#140082","#100068","#0c0053","#FFFFFF"],indigo=["#3c0068","#300053","#260042","#1e0034","#180029","#FFFFFF"],violet=["#6500cc","#5000a3","#400082","#330068","#280053","#FFFFFF"],pink=["#eb8898","#a33058","#FFC0CB","#681e38","#53182c","#FFFFFF"],crimson=["#b01030","#8c0c26","#70091e","#590718","#470513","#FFFFFF"],brown=["#793000","#602600","#4c1e00","#3c1800","#301300","#FFFFFF"],gray=["#787878","#606060","#4c4c4c","#3c3c3c","#303030","#FFFFFF"],white=["#cccccc","#a3a3a3","#FFFFFF","#686868","#535353","#000000"],black=["#191919","#141414","#101010","#0c0c0c","#090909","#80FF00"],magenta=["#cc00cc","#a300a3","#820082","#680068","#530053","#FFFFFF"];function colorChanger($){let e=[];switch($){case"red":e=red;break;case"orange":e=orange;break;case"yellow":e=yellow;break;case"green":e=green;break;case"blue":e=blue;break;case"indigo":e=indigo;break;case"violet":e=violet;break;case"pink":e=pink;break;case"crimson":e=crimson;break;case"brown":e=brown;break;case"gray":e=gray;break;case"white":e=white;break;case"black":e=black;break;case"magenta":e=magenta}let c=document.querySelectorAll(".icebot button"),o=document.querySelectorAll(".icebot"),r=document.querySelector(".option"),l=document.querySelectorAll(".option button"),a=document.querySelectorAll(".userlist"),t=document.querySelectorAll('.userlist input[type="submit"]'),F=document.querySelectorAll('.icebot input[type="range"]'),n=document.querySelectorAll(".icebot h2"),s=document.querySelectorAll('.icebot input[type="submit"]');n.forEach($=>{$.style.color=e[5]}),r.style.backgroundColor=e[2],F.forEach($=>{$.style.accentColor=e[0]}),o.forEach($=>{$.style.backgroundColor=e[2]}),c.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5],$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})}),l.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5]}),s.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5],$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})}),a.forEach($=>{$.style.backgroundColor=e[2],$.style.color=e[5]}),t.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5]});let b=document.querySelectorAll(".option button");document.querySelectorAll(".option button svg").forEach($=>{$.style.stroke=e[5]}),b.forEach($=>{$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})})}function setmenu(menu){const elements=['#icebot1','#icebot2','#icebot3','#icebot4',"#icebot5","#icebot6","#icebot7","#icebot8",'#avatarlist','#cavatarlist','#custombotnick'];elements.forEach(element=>{if(element===`#${menu}`){f(element).style.display='block';}else{f(element).style.display='none';}})};
function xmv() { const userAgent = navigator.userAgent.toLowerCase(); const dM = ['android', 'webos', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone']; for (let d of dM) {if (userAgent.includes(d)) { function x(){ let ice = document.querySelectorAll(".icebot");let optionBtn= document.querySelectorAll(".option button");let option= document.querySelectorAll(".option");ice.forEach(icebot=>{icebot.style.width="220px";icebot.style.left="110px"});option.forEach(option=>{option.style.left="180px";option.style.top="600px";option.style.width="320px";option.style.height="auto";});optionBtn.forEach(option=>{option.style.width="13%"});setTimeout(()=>{document.querySelector("#avatarlist").style.width="360px";document.querySelector("#avatarlist").style.left="187px";
document.querySelector("#cavatarlist").style.width="360px";document.querySelector("#cavatarlist").style.left="187px";
document.querySelector("#custombotnick").style.width="360px";document.querySelector("#custombotnick").style.left="187px"},200) };x();}}};setTimeout(()=>{xmv();},200)
//aaa
 

//aaa
 addStyle(`        @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');        .userlist *{box-sizing:border-box;}        .userlist {            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;font-style:italic;            position:fixed;left:50%;top:3px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto !important;width:200px !important;        }        .userlist input[type=text]{height:20px;border-radius:3px;font-size:9pt;background:brown;color:white;padding-left:3px;}        .userlist input[type=submit]{height:25px;border-radius:3px;background:#FFD700;}        .userlist input[type=checkbox]{margin-top:2px;}        #background{        z-index:999;width:0px;height:0px;position:fixed;left:0px;top:0px;        }        .option *{box-sizing:border-box;}        .option {            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:14%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto;width:40px;        }        .option input[type=submit],.option button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .option input[type=checkbox]{margin-top:2px;}        .option input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .option button:hover{background:#ccad00;transition:0.2s;}        .option button:hover svg {stroke: #9e6e1c;}        .option button{width:90%;}        .icebot *{box-sizing:border-box;}        #avatarlist,#custombotnick,#cavatarlist {            overflow-x:hidden;width:100%;max-height:450px;overflow-y:scroll;            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:50px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:400px;        .avatarbtn{display:flex;align-items:center;justify-content:center;}        .avatarbtn button,.avatarbtn button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:50px;font-size:11pt;margin-top:5px;}        .avatarbtn button:hover{background:#ccad00;transition:0.2s;}        }        #icebot1,#icebot2,#icebot6,#icebot7,#icebot8,#icebotlog,#wordlist{            overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto;width:240px;        }        #icebot3 {            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .broadcastspamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .messagespamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .answerspamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .broadcastspam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .messagespam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .answerspam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        #broadcaststop{display:none;}        #msgstop{display:none;}        #answerstop{display:none;}     .msgjointext{margin-top:3px; text-align:center; color:#FFD700; font-size:17px;} .roomselectortext{margin-top:3px; text-align:center; color:#FFD700; font-size:17px;}       }        #icebot4 {            overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .kicklistbox{display:flex;align-items:center;justify-content:center;}        .kicklistbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .kicklistbox input[type=submit],.kicklistbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .kicklistbox input[type=submit]:hover{background:#ccad00;transition:0.2s;}        #kicklistaddbtn{width:40%;}        #kicklistremoveallbtn{width:40%;}        .customkickremove{width:30%;}        .customkick{margin-top:3px; text-align:center; color:#FFD700; font-size:17px;}        }        #icebot5 {            display:none;text-align:center;opacity:none;overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .autoguess{width:40%;}        #autoguessenable{align-items:center;justify-content:center;}        #autoguessdisable{display:none;align-items:center;justify-content:center;}        .autoguessstyle{display:flex;align-items:center;justify-content:center;}        .mimicmode{width:40%;}        #mimicmodeenabled{align-items:center;justify-content:center;}        #mimicmodedisabled{display:none;align-items:center;justify-content:center;}        .mimicmodestyle{display:flex;align-items:center;justify-content:center;}        .rainbowdraw{width:30%;}        #rainbowdrawenabled{align-items:center;justify-content:center;}        #rainbowdrawdisabled{display:none;align-items:center;justify-content:center;}        .rainbowdrawstyle{display:flex;align-items:center;justify-content:center;}        .msgjoinremoveall{width:40%;}        }        .icebot input[type=submit],.icebotbtn button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .icebot input[type=checkbox]{margin-top:2px;}        .icebot input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .icebot input[type=range]{accent-color:#FFD700;}        .icebot input[type=range]:focus::-webkit-slider-runnable-track { background: #3071A9; }        #join{width:20%;}        .roomlink{display:flex;align-items:center;justify-content:center;}        .roomlink input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .roomlink input[type=submit],.broadcastbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .roomlink button:hover{background:#ccad00;transition:0.2s;}        .botnick input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .broadcastbox{display:flex;align-items:center;justify-content:center;}        .broadcastbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .broadcastbox input[type=submit],.broadcastbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .broadcastbox button:hover{background:#ccad00;transition:0.2s;}        .msgbox{display:flex;align-items:center;justify-content:center;}        .msgbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .msgbox input[type=submit],.msgbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .msgbox button:hover{background:#ccad00;transition:0.2s;}        .answerbox{display:flex;align-items:center;justify-content:center;}        .answerbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .answerbox input[type=submit],.answerbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .answerbox button:hover{background:#ccad00;transition:0.2s;}        .msgboxjoin{display:flex;align-items:center;justify-content:center;}        .msgboxjoin input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .msgboxjoin input[type=submit],.msgboxjoin button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .msgboxjoin button:hover{background:#ccad00;transition:0.2s;}        .botnick0{width:50%;}        .botnick1{width:50%;} .botnick2{width:50%;} .botnick3{width:50%;} .botnick4{width:50%;}   .cbotnick{width:80%;}        .chooseavatar{width:80%;}        .broadcastbtn{width:20%;},.broadcastbtn input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .msgbtn{width:20%;}        .answerbtn{width:20%;}        .report{width:40%;} .0xbE{width:40%;}  .dupejoin{width:40%;}      .kickall{width:40%;}        .jump{width:40%;}        .exit{width:40%;}        .rejoin{width:40%;}        .active-afk{width:40%;}        .acceptdraw1{width:40%;}        .acceptdraw2{width:40%;}        .tips{width:40%;}        .autoreport input[type=checkbox]{margin-top:32px}        .autoskip{margin-top:32px;}        .antikick{margin-top:32px;}        .antiafk{margin-top:32px;}        .autokick{margin-top:32px;}        .about{position:absolute;left:20px;top:-3px;width:10%}        .roomconsole{margin-top:3px; text-align:left; color:#FFD700; font-size:17px;}        .roomtheme{margin-top:3px; text-align:left; color:#FFD700; font-size:17px;}.switch {  position: relative;  display: block;  width: 60px;  height: 34px;}.switch input {  opacity: 0;  width: 0;  height: 0;}.slider {  position: absolute;  cursor: pointer;  top: 0;  left: 0;  right: 0;  bottom: 0;  background-color: #ccc;  -webkit-transition: .1s;  transition: .1s;}.slider:before {  position: absolute;  content: "";  height: 26px;  width: 26px;  left: 4px;  bottom: 4px;  background-color: white;  -webkit-transition: .1s;  transition: .1s;}input:checked + .slider {  background-color: #FFD700;}input:focus + .slider {  box-shadow: 0 0 1px #FFD700;}input:checked + .slider:before {  -webkit-transform: translateX(26px);  -ms-transform: translateX(26px);  transform: translateX(26px);}/* Rounded sliders */.slider.round {  border-radius: 34px;}.slider.round:before {  border-radius: 50%;}        .colorthemesbtn1{width:40%;}        .colorthemesbtn2{width:60%;}.swal2-popup.swal2-toast{flex-direction:column;align-items:stretch;width:auto;padding:1.25em;overflow-y:hidden;background:#fff;box-shadow:0 0 .625em #d9d9d9}.swal2-popup.swal2-toast .swal2-header{flex-direction:row;padding:0}.swal2-popup.swal2-toast .swal2-title{flex-grow:1;justify-content:flex-start;margin:0 .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-loading{justify-content:center}.swal2-popup.swal2-toast .swal2-input{height:2em;margin:.3125em auto;font-size:1em}.swal2-popup.swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{position:static;width:.8em;height:.8em;line-height:.8}.swal2-popup.swal2-toast .swal2-content{justify-content:flex-start;margin:0 .625em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-html-container{padding:.625em 0 0}.swal2-popup.swal2-toast .swal2-html-container:empty{padding:0}.swal2-popup.swal2-toast .swal2-icon{width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:700}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{font-size:.25em}}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{flex:1;flex-basis:auto!important;align-self:stretch;width:auto;height:2.2em;height:auto;margin:0 .3125em;margin-top:.3125em;padding:0}.swal2-popup.swal2-toast .swal2-styled{margin:.125em .3125em;padding:.3125em .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-styled:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(100,150,200,.5)}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.8em;left:-.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-toast-animate-success-line-tip .75s;animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-toast-animate-success-line-long .75s;animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{-webkit-animation:swal2-toast-show .5s;animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{-webkit-animation:swal2-toast-hide .1s forwards;animation:swal2-toast-hide .1s forwards}.swal2-container{display:flex;position:fixed;z-index:1060;top:0;right:0;bottom:0;left:0;flex-direction:row;align-items:center;justify-content:center;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}.swal2-container.swal2-backdrop-show,.swal2-container.swal2-noanimation{background:rgba(0,0,0,.4)}.swal2-container.swal2-backdrop-hide{background:0 0!important}.swal2-container.swal2-top{align-items:flex-start}.swal2-container.swal2-top-left,.swal2-container.swal2-top-start{align-items:flex-start;justify-content:flex-start}.swal2-container.swal2-top-end,.swal2-container.swal2-top-right{align-items:flex-start;justify-content:flex-end}.swal2-container.swal2-center{align-items:center}.swal2-container.swal2-center-left,.swal2-container.swal2-center-start{align-items:center;justify-content:flex-start}.swal2-container.swal2-center-end,.swal2-container.swal2-center-right{align-items:center;justify-content:flex-end}.swal2-container.swal2-bottom{align-items:flex-end}.swal2-container.swal2-bottom-left,.swal2-container.swal2-bottom-start{align-items:flex-end;justify-content:flex-start}.swal2-container.swal2-bottom-end,.swal2-container.swal2-bottom-right{align-items:flex-end;justify-content:flex-end}.swal2-container.swal2-bottom-end>:first-child,.swal2-container.swal2-bottom-left>:first-child,.swal2-container.swal2-bottom-right>:first-child,.swal2-container.swal2-bottom-start>:first-child,.swal2-container.swal2-bottom>:first-child{margin-top:auto}.swal2-container.swal2-grow-fullscreen>.swal2-modal{display:flex!important;flex:1;align-self:stretch;justify-content:center}.swal2-container.swal2-grow-row>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-grow-column{flex:1;flex-direction:column}.swal2-container.swal2-grow-column.swal2-bottom,.swal2-container.swal2-grow-column.swal2-center,.swal2-container.swal2-grow-column.swal2-top{align-items:center}.swal2-container.swal2-grow-column.swal2-bottom-left,.swal2-container.swal2-grow-column.swal2-bottom-start,.swal2-container.swal2-grow-column.swal2-center-left,.swal2-container.swal2-grow-column.swal2-center-start,.swal2-container.swal2-grow-column.swal2-top-left,.swal2-container.swal2-grow-column.swal2-top-start{align-items:flex-start}.swal2-container.swal2-grow-column.swal2-bottom-end,.swal2-container.swal2-grow-column.swal2-bottom-right,.swal2-container.swal2-grow-column.swal2-center-end,.swal2-container.swal2-grow-column.swal2-center-right,.swal2-container.swal2-grow-column.swal2-top-end,.swal2-container.swal2-grow-column.swal2-top-right{align-items:flex-end}.swal2-container.swal2-grow-column>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-no-transition{transition:none!important}.swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right):not(.swal2-grow-fullscreen)>.swal2-modal{margin:auto}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-container .swal2-modal{margin:0!important}}.swal2-popup{display:none;position:relative;box-sizing:border-box;flex-direction:column;justify-content:center;width:32em;max-width:100%;padding:1.25em;border:none;border-radius:5px;background:#fff;font-family:inherit;font-size:1rem}.swal2-popup:focus{outline:0}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-header{display:flex;flex-direction:column;align-items:center;padding:0 1.8em}.swal2-title{position:relative;max-width:100%;margin:0 0 .4em;padding:0;color:#595959;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-actions{display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:100%;margin:1.25em auto 0;padding:0}.swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1))}.swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2))}.swal2-loader{display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 transparent #2778c4 transparent}.swal2-styled{margin:.3125em;padding:.625em 1.1em;box-shadow:none;font-weight:500}.swal2-styled:not([disabled]){cursor:pointer}.swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#2778c4;color:#fff;font-size:1em}.swal2-styled.swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#d14529;color:#fff;font-size:1em}.swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#757575;color:#fff;font-size:1em}.swal2-styled:focus{outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-styled::-moz-focus-inner{border:0}.swal2-footer{justify-content:center;margin:1.25em 0 0;padding:1em 0 0;border-top:1px solid #eee;color:#545454;font-size:1em}.swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;height:.25em;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.swal2-timer-progress-bar{width:100%;height:.25em;background:rgba(0,0,0,.2)}.swal2-image{max-width:100%;margin:1.25em auto}.swal2-close{position:absolute;z-index:2;top:0;right:0;align-items:center;justify-content:center;width:1.2em;height:1.2em;padding:0;overflow:hidden;transition:color .1s ease-out;border:none;border-radius:5px;background:0 0;color:#ccc;font-family:serif;font-size:2.5em;line-height:1.2;cursor:pointer}.swal2-close:hover{transform:none;background:0 0;color:#f27474}.swal2-close:focus{outline:0;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}.swal2-close::-moz-focus-inner{border:0}.swal2-content{z-index:1;justify-content:center;margin:0;padding:0 1.6em;color:#545454;font-size:1.125em;font-weight:400;line-height:normal;text-align:center;word-wrap:break-word}.swal2-checkbox,.swal2-file,.swal2-input,.swal2-radio,.swal2-select,.swal2-textarea{margin:1em auto}.swal2-file,.swal2-input,.swal2-textarea{box-sizing:border-box;width:100%;transition:border-color .3s,box-shadow .3s;border:1px solid #d9d9d9;border-radius:.1875em;background:inherit;box-shadow:inset 0 1px 1px rgba(0,0,0,.06);color:inherit;font-size:1.125em}.swal2-file.swal2-inputerror,.swal2-input.swal2-inputerror,.swal2-textarea.swal2-inputerror{border-color:#f27474!important;box-shadow:0 0 2px #f27474!important}.swal2-file:focus,.swal2-input:focus,.swal2-textarea:focus{border:1px solid #b4dbed;outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-file::-moz-placeholder,.swal2-input::-moz-placeholder,.swal2-textarea::-moz-placeholder{color:#ccc}.swal2-file:-ms-input-placeholder,.swal2-input:-ms-input-placeholder,.swal2-textarea:-ms-input-placeholder{color:#ccc}.swal2-file::placeholder,.swal2-input::placeholder,.swal2-textarea::placeholder{color:#ccc}.swal2-range{margin:1em auto;background:#fff}.swal2-range input{width:80%}.swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}.swal2-range input,.swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}.swal2-input{height:2.625em;padding:0 .75em}.swal2-input[type=number]{max-width:10em}.swal2-file{background:inherit;font-size:1.125em}.swal2-textarea{height:6.75em;padding:.75em}.swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:inherit;color:inherit;font-size:1.125em}.swal2-checkbox,.swal2-radio{align-items:center;justify-content:center;background:#fff;color:inherit}.swal2-checkbox label,.swal2-radio label{margin:0 .6em;font-size:1.125em}.swal2-checkbox input,.swal2-radio input{flex-shrink:0;margin:0 .4em}.swal2-input-label{display:flex;justify-content:center;margin:1em auto}.swal2-validation-message{align-items:center;justify-content:center;margin:0 -2.7em;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}.swal2-validation-message::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}.swal2-icon{position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:1.25em auto 1.875em;border:.25em solid transparent;border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474;color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}.swal2-icon.swal2-error.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark{-webkit-animation:swal2-animate-error-x-mark .5s;animation:swal2-animate-error-x-mark .5s}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-success{border-color:#a5dc86;color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-.25em;left:-.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-animate-success-line-tip .75s;animation:swal2-animate-success-line-tip .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-animate-success-line-long .75s;animation:swal2-animate-success-line-long .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right{-webkit-animation:swal2-rotate-success-circular-line 4.25s ease-in;animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:0 0 1.25em;padding:0;background:inherit;font-weight:600}.swal2-progress-steps li{display:inline-block;position:relative}.swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}.swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}[class^=swal2]{-webkit-tap-highlight-color:transparent}.swal2-show{-webkit-animation:swal2-show .3s;animation:swal2-show .3s}.swal2-hide{-webkit-animation:swal2-hide .15s forwards;animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{right:auto;left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@supports (-ms-accelerator:true){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@-webkit-keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@-webkit-keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@-webkit-keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@-webkit-keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@-webkit-keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@-webkit-keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@-webkit-keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@-webkit-keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@-webkit-keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@-webkit-keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@-webkit-keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@-webkit-keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto!important}body.swal2-no-backdrop .swal2-container{top:auto;right:auto;bottom:auto;left:auto;max-width:calc(100% - .625em * 2);background-color:transparent!important}body.swal2-no-backdrop .swal2-container>.swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}body.swal2-no-backdrop .swal2-container.swal2-top{top:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-top-left,body.swal2-no-backdrop .swal2-container.swal2-top-start{top:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-top-end,body.swal2-no-backdrop .swal2-container.swal2-top-right{top:0;right:0}body.swal2-no-backdrop .swal2-container.swal2-center{top:50%;left:50%;transform:translate(-50%,-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-left,body.swal2-no-backdrop .swal2-container.swal2-center-start{top:50%;left:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-end,body.swal2-no-backdrop .swal2-container.swal2-center-right{top:50%;right:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom{bottom:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom-left,body.swal2-no-backdrop .swal2-container.swal2-bottom-start{bottom:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-bottom-end,body.swal2-no-backdrop .swal2-container.swal2-bottom-right{right:0;bottom:0}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll!important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static!important}}body.swal2-toast-shown .swal2-container{background-color:transparent}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-left,body.swal2-toast-shown .swal2-container.swal2-top-start{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-left,body.swal2-toast-shown .swal2-container.swal2-center-start{top:50%;right:auto;bottom:auto;left:0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;transform:translate(-50%,-50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-left,body.swal2-toast-shown .swal2-container.swal2-bottom-start{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}`);addHtml(`<div class="userlist" style="display:none">    <div class="userkickmenu"></div>    <input type="submit" style="width:90px; background:red" onclick="window.postMessage('kickall','*')" value="KICK ALL">        <input type="checkbox" class="kickonjoin">&nbsp;Kick on join<br>        <input type="checkbox" class="kickallwhenjoin">&nbsp;Kick when join<hr>    </div>    <div class="option">    <button class="hidemenu" onclick="window.postMessage('hidemenu','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg></button>    <button class="menu1" onclick="window.postMessage('menu1','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button>    <button class="menu2" onclick="window.postMessage('menu2','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 9v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9"/><path d="M9 22V12h6v10M2 10.6L12 2l10 8.6"/></svg></button>    <button class="menu3" onclick="window.postMessage('menu3','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></button>    <button class="menu4" onclick="window.postMessage('menu4','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="18" y1="8" x2="23" y2="13"></line><line x1="23" y1="8" x2="18" y2="13"></line></svg></button>    <button class="menu5" onclick="window.postMessage('menu5','*')"><span>🆕️</span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg></button>    <button class="menu6" onclick="window.postMessage('menu6','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></button>  <button class="menu7" onclick="window.postMessage('menu7','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></button></button>  <button class="menu8" onclick="window.postMessage('menu8','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg></button>    </div>    <div id="avatarlist" class="icebot">    <input type="submit" class="hideavatarlist" onclick="window.postMessage('hideavatarlist','*')" value="CLOSE"><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/0.svg" class="selectedavatar" onclick="window.postMessage('avatar.0','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/1.svg" class="selectedavatar" onclick="window.postMessage('avatar.1','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/2.svg" class="selectedavatar" onclick="window.postMessage('avatar.2','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/3.svg" class="selectedavatar" onclick="window.postMessage('avatar.3','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/4.svg" class="selectedavatar" onclick="window.postMessage('avatar.4','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/5.svg" class="selectedavatar" onclick="window.postMessage('avatar.5','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/6.svg" class="selectedavatar" onclick="window.postMessage('avatar.6','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/7.svg" class="selectedavatar" onclick="window.postMessage('avatar.7','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/8.svg" class="selectedavatar" onclick="window.postMessage('avatar.8','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/9.svg" class="selectedavatar" onclick="window.postMessage('avatar.9','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/10.svg" class="selectedavatar" onclick="window.postMessage('avatar.10','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/11.svg" class="selectedavatar" onclick="window.postMessage('avatar.11','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/12.svg" class="selectedavatar" onclick="window.postMessage('avatar.12','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/13.svg" class="selectedavatar" onclick="window.postMessage('avatar.13','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/14.svg" class="selectedavatar" onclick="window.postMessage('avatar.14','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/15.svg" class="selectedavatar" onclick="window.postMessage('avatar.15','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/16.svg" class="selectedavatar" onclick="window.postMessage('avatar.16','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/17.svg" class="selectedavatar" onclick="window.postMessage('avatar.17','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/18.svg" class="selectedavatar" onclick="window.postMessage('avatar.18','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/19.svg" class="selectedavatar" onclick="window.postMessage('avatar.19','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/20.svg" class="selectedavatar" onclick="window.postMessage('avatar.20','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/21.svg" class="selectedavatar" onclick="window.postMessage('avatar.21','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/22.svg" class="selectedavatar" onclick="window.postMessage('avatar.22','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/23.svg" class="selectedavatar" onclick="window.postMessage('avatar.23','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/24.svg" class="selectedavatar" onclick="window.postMessage('avatar.24','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/25.svg" class="selectedavatar" onclick="window.postMessage('avatar.25','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/26.svg" class="selectedavatar" onclick="window.postMessage('avatar.26','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/27.svg" class="selectedavatar" onclick="window.postMessage('avatar.27','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/28.svg" class="selectedavatar" onclick="window.postMessage('avatar.28','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/29.svg" class="selectedavatar" onclick="window.postMessage('avatar.29','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/30.svg" class="selectedavatar" onclick="window.postMessage('avatar.30','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/31.svg" class="selectedavatar" onclick="window.postMessage('avatar.31','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/32.svg" class="selectedavatar" onclick="window.postMessage('avatar.32','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/33.svg" class="selectedavatar" onclick="window.postMessage('avatar.33','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/34.svg" class="selectedavatar" onclick="window.postMessage('avatar.34','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/35.svg" class="selectedavatar" onclick="window.postMessage('avatar.35','*')"></button></div><div class="avatarbtn"><button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/36.svg" class="selectedavatar" onclick="window.postMessage('avatar.36','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://garticphone.com/images/avatar/31.svg" class="selectedavatar" onclick="window.postMessage('avatar.null','*')"></button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/subjects/1.svg?v=1" class="selectedavatar" onclick="window.postMessage('avatar.random','*')"></button></div><br>    </div>   <div id="icebot1" style="display:none"; class="icebot">    <h2 style="color:white;">ICEbot V6  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="botnumber"></span><input type="submit" class="about" onclick="window.postMessage('info','*')" value="ⓘ"></h2>    <h2 style="color:white;">Bot amount: &nbsp;&nbsp;<span><input type="text" id="quantbot" style="width:15%" oninput="window.postMessage('quantbot','*')"  value="`+localStorage.getItem("quant")+`"><span></h2><div class="roomlink"><input type="text" id="roomlink" placeholder="Room link"><input type="submit" id="join" onclick="window.postMessage('join','*')" value="JOIN"></div>    <div class="botnick"><input type="text" id="botnick" oninput="window.postMessage('nick','*')" placeholder="Bot nick" value="`+localStorage.getItem("nick")+`"></div> <select id="optcmb" style="background-color:white" onchange="javascript:localStorage.setItem('botnick',6);localStorage.setItem('combining',this.value);"><optgroup label="Combining Characters">
   <option value="0">ICEbot</option>
   <option value="1">ÌC̀Èb̀òt̀</option>
   <option value="2">ÍĆÉb́ót́</option>
   <option value="3">ÎĈÊb̂ôt̂</option>
   <option value="4">ĨC̃Ẽb̃õt̃</option>
   <option value="5">ĪC̄Ēb̄ōt̄</option>
   <option value="6">I̅C̅E̅b̅o̅t̅</option>
   <option value="7">ĬC̆Ĕb̆ŏt̆</option>
   <option value="8">İĊĖḃȯṫ</option>
   <option value="9">ÏC̈Ëb̈öẗ</option>
   <option value="10">ỈC̉Ẻb̉ỏt̉</option>
   <option value="11">I̊C̊E̊b̊o̊t̊</option>
   <option value="12">I̋C̋E̋b̋őt̋</option>
   <option value="13">ǏČĚb̌ǒť</option>
   <option value="14">I̍C̍E̍b̍o̍t̍</option>
   <option value="15">I̎C̎E̎b̎o̎t̎</option>
   <option value="16">ȈC̏Ȅb̏ȍt̏</option>
   <option value="17">I̐C̐E̐b̐o̐t̐</option>
   <option value="18">ȊC̑Ȇb̑ȏt̑</option>
   <option value="19">I̒C̒E̒b̒o̒t̒</option>
   <option value="20">I̓C̓E̓b̓o̓t̓</option>
   <option value="21">I̔C̔E̔b̔o̔t̔</option>
   <option value="22">I̕C̕E̕b̕o̕t̕</option>
   <option value="23">I̖C̖E̖b̖o̖t̖</option>
   <option value="24">I̗C̗E̗b̗o̗t̗</option>
   <option value="25">I̘C̘E̘b̘o̘t̘</option>
   <option value="26">I̙C̙E̙b̙o̙t̙</option>
   <option value="27">I̚C̚E̚b̚o̚t̚</option>
   <option value="28">I̛C̛E̛b̛ơt̛</option>
   <option value="29">I̜C̜E̜b̜o̜t̜</option>
   <option value="30">I̝C̝E̝b̝o̝t̝</option>
   <option value="31">I̞C̞E̞b̞o̞t̞</option>
   <option value="32">I̟C̟E̟b̟o̟t̟</option>
   <option value="33">I̠C̠E̠b̠o̠t̠</option>
   <option value="34">I̡C̡E̡b̡o̡t̡</option>
   <option value="35">I̢C̢E̢b̢o̢t̢</option>
   <option value="36">ỊC̣Ẹḅọṭ</option>
   <option value="37">I̤C̤E̤b̤o̤t̤</option>
   <option value="38">I̥C̥E̥b̥o̥t̥</option>
   <option value="39">I̦C̦E̦b̦o̦ț</option>
   <option value="40">I̧ÇȨb̧o̧ţ</option>
   <option value="41">ĮC̨Ęb̨ǫt̨</option>
   <option value="42">I̩C̩E̩b̩o̩t̩</option>
   <option value="43">I̪C̪E̪b̪o̪t̪</option>
   <option value="44">I̫C̫E̫b̫o̫t̫</option>
   <option value="45">I̬C̬E̬b̬o̬t̬</option>
   <option value="46">I̭C̭Ḙb̭o̭ṱ</option>
   <option value="47">I̮C̮E̮b̮o̮t̮</option>
   <option value="48">I̯C̯E̯b̯o̯t̯</option>
   <option value="49">ḬC̰Ḛb̰o̰t̰</option>
   <option value="50">I̱C̱E̱ḇo̱ṯ</option>
   <option value="51">I̲C̲E̲b̲o̲t̲</option>
   <option value="52">I̳C̳E̳b̳o̳t̳</option>
   <option value="53">I̴C̴E̴b̴o̴t̴</option>
   <option value="54">I̵C̵E̵b̵o̵t̵</option>
   <option value="55">I̶C̶E̶b̶o̶t̶</option>
   <option value="56">I̷C̷E̷b̷o̷t̷</option>
   <option value="57">I̸C̸E̸b̸o̸t̸</option>
   <option value="58">I̹C̹E̹b̹o̹t̹</option>
   <option value="59">I̺C̺E̺b̺o̺t̺</option>
   <option value="60">I̻C̻E̻b̻o̻t̻</option>
   <option value="61">I̼C̼E̼b̼o̼t̼</option>
   <option value="62">I̽C̽E̽b̽o̽t̽</option>
   <option value="63">I̾C̾E̾b̾o̾t̾</option>
   <option value="64">I̿C̿E̿b̿o̿t̿</option>
   <option value="65">ÌC̀Èb̀òt̀</option>
   <option value="66">ÍĆÉb́ót́</option>
   <option value="67">I͂C͂E͂b͂o͂t͂</option>
   <option value="68">I̓C̓E̓b̓o̓t̓</option>
   <option value="69">ḮC̈́Ë́b̈́ö́ẗ́</option>
   <option value="70">IͅCͅEͅbͅoͅtͅ</option>
   <option value="71">I͆C͆E͆b͆o͆t͆</option>
   <option value="72">I͇C͇E͇b͇o͇t͇</option>
   <option value="73">I͈C͈E͈b͈o͈t͈</option>
   <option value="74">I͉C͉E͉b͉o͉t͉</option>
   <option value="75">I͊C͊E͊b͊o͊t͊</option>
   <option value="76">I͋C͋E͋b͋o͋t͋</option>
   <option value="77">I͌C͌E͌b͌o͌t͌</option>
   <option value="78">I͍C͍E͍b͍o͍t͍</option>
   <option value="79">I͎C͎E͎b͎o͎t͎</option>
   <option value="80">I͏C͏E͏b͏o͏t͏</option>
   <option value="81">I͐C͐E͐b͐o͐t͐</option>
   <option value="82">I͑C͑E͑b͑o͑t͑</option>
   <option value="83">I͒C͒E͒b͒o͒t͒</option>
   <option value="84">I͓C͓E͓b͓o͓t͓</option>
   <option value="85">I͔C͔E͔b͔o͔t͔</option>
   <option value="86">I͕C͕E͕b͕o͕t͕</option>
   <option value="87">I͖C͖E͖b͖o͖t͖</option>
   <option value="88">I͗C͗E͗b͗o͗t͗</option>
   <option value="89">I͘C͘E͘b͘o͘t͘</option>
   <option value="90">I͙C͙E͙b͙o͙t͙</option>
   <option value="91">I͚C͚E͚b͚o͚t͚</option>
   <option value="92">I͛C͛E͛b͛o͛t͛</option>
   <option value="93">I͜C͜E͜b͜o͜t͜</option>
   <option value="94">I͝C͝E͝b͝o͝t͝</option>
   <option value="95">I͞C͞E͞b͞o͞t͞</option>
   <option value="96">I͟C͟E͟b͟o͟t͟</option>
   <option value="97">I͠C͠E͠b͠o͠t͠</option>
   <option value="98">I͡C͡E͡b͡o͡t͡</option>
   <option value="99">I͢C͢E͢b͢o͢t͢</option>
   <option value="100">IͣCͣEͣbͣoͣtͣ</option>
   <option value="101">IͤCͤEͤbͤoͤtͤ</option>
   <option value="102">IͥCͥEͥbͥoͥtͥ</option>
   <option value="103">IͦCͦEͦbͦoͦtͦ</option>
   <option value="104">IͧCͧEͧbͧoͧtͧ</option>
   <option value="105">IͨCͨEͨbͨoͨtͨ</option>
   <option value="106">IͩCͩEͩbͩoͩtͩ</option>
   <option value="107">IͪCͪEͪbͪoͪtͪ</option>
   <option value="108">IͫCͫEͫbͫoͫtͫ</option>
   <option value="109">IͬCͬEͬbͬoͬtͬ</option>
   <option value="110">IͭCͭEͭbͭoͭtͭ</option>
   <option value="111">IͮCͮEͮbͮoͮtͮ</option>
   <option value="112">IͯCͯEͯbͯoͯtͯ</option></optgroup></select>
   <input type="submit" class="botnick0" onclick="window.postMessage('botnick0','*')" value="Bot nick 1">    <input type="submit" class="botnick1" onclick="window.postMessage('botnick1','*')" value="Bot nick 2"><input type="submit" class="botnick2" onclick="window.postMessage('botnick2','*')" value="Bot nick 3"><input type="submit" class="botnick3" onclick="window.postMessage('botnick3','*')" value="Bot nick 4"><input type="submit" class="botnick4" onclick="window.postMessage('botnick4','*')" value="Bot nick 5"><input type="submit" class="cbotnick" onclick="window.postMessage('cnickshow','*')" value="custom bot nick"><br><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/`+localStorage.getItem("avatar")+`.svg" id="avatar" class="selectedavatar">    <input type="submit" class="chooseavatar" onclick="window.postMessage('showavatarlist','*')" value="CHOOSE AVATAR">    </div>    <div id="icebot2" class="icebot" style="display:none;"><div class="broadcastbox"><input type="text" id="broadcast" placeholder="Broadcast"><button class="broadcastbtn" onclick="window.postMessage('broadcast','*')" value="Broadcast"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">  <path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button><button class="msgbtn" style="width:10%" onclick="window.postMessage('broadcastspam','*')" value="Broadcast"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button></div>    <div class="msgbox"><input type="text" id="message" placeholder="Message"><button class="msgbtn" onclick="window.postMessage('chat','*')" value="Message"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">  <path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button><button class="msgbtn" style="width:10%" onclick="window.postMessage('chatspam','*')" value="Message"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button></div>    <div class="answerbox"><input type="text" id="answer" placeholder="Answer"><button class="answerbtn" onclick="window.postMessage('answer','*')" value="Answer"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">  <path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button><button class="msgbtn" style="width:10%" onclick="window.postMessage('answerspam','*')" value="Answer"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button></div>    <input type="submit" class="exit" style="background:red;" onclick="window.postMessage('exit','*')" value="EXIT">    <input type="submit" class="kickall" onclick="window.postMessage('kickall','*')" value="KICK ALL">    <input type="submit" class="report" onclick="window.postMessage('report','*')" value="REPORT">    <input type="submit" class="rejoin" onclick="window.postMessage('rejoin','*')" value="REJOIN">    <input type="submit" class="jump" onclick="window.postMessage('jump','*')" value="JUMP">    <input type="submit" class="active-afk" onclick="window.postMessage('afkconfirm','*')" value="ACTIVE">  <input type="text" style="width:40%" id="word1"> <input type="text" style="width:40%" id="word2">     <input type="submit" class="acceptdraw1" onclick="window.postMessage('acceptdraw1','*')" value="DRAW 1">    <input type="submit" class="acceptdraw2" onclick="window.postMessage('acceptdraw2','*')" value="DRAW 2">    <input type="submit" class="tips" onclick="window.postMessage('tips','*')" value="TIPS"><input type="submit" class="0xbE" style="display:none;" onclick="window.postMessage('0xbE','*')" value="0xbE">  <input type="submit" class="dupejoin" onclick="window.postMessage('dupejoin','*')" value="DUPE JOIN">  <br>    <h2 class="roomconsole"></h2><span><h2 class="roomtheme"></h2></span></div>    <div id="icebot3" class="icebot">    <div class="broadcastbox"><input type="text" id="broadcastspam" placeholder="Broadcast (spam)"><button class="broadcastbtn" id="broadcaststart" onclick="window.postMessage('broadcastspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="broadcastbtn" id="broadcaststop" onclick="window.postMessage('stopbroadcast','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div>    <div class="msgbox"><input type="text" id="messagespam" placeholder="Message (spam)"><button class="msgbtn" id="msgstart" onclick="window.postMessage('chatspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="msgbtn" id="msgstop" onclick="window.postMessage('stopmsg','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div>    <div class="answerbox"><input type="text" id="answerspam" placeholder="Answer (spam)"><button class="answerbtn" id="answerstart" onclick="window.postMessage('answerspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="answerbtn" id="answerstop" onclick="window.postMessage('stopanswer','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div><h2 class="broadcastspamvalue" id="broadcastms"></h2><input class="broadcastspam" type="range" oninput="postMessage('broadcastspam')" min="1000" max="10000"><h2 class="messagespamvalue" id="messagems"></h2><input class="messagespam" type="range" oninput="postMessage('messagespam')" min="1000" max="10000"><h2 class="answerspamvalue" id="answerms"></h2><input class="answerspam" type="range" oninput="postMessage('answerspam')" min="1000" max="10000">    </div>    <div id="icebot4" class="icebot">    <h2 class="customkick">Custom kick</h2> <div class="kicklistbox">      <input type="text" id="kicklistinput" placeholder="Player name"></input>  <input type="submit" id="kicklistaddbtn" onclick="window.postMessage('customkickadd','*')" value="add"></input></div><input type="submit" id="kicklistremoveallbtn" onclick="window.postMessage('customkickremoveall','*')" value="remove all"></div>    <div id="icebot5" class="icebot"><h2 id="proxylist">Proxy list • ACTIVE</h2><input type="submit" class="report" onclick="window.postMessage('getlocation','*')" value="get location"><input type="submit" class="report" onclick="window.postMessage('refreshall','*')" value="refresh all"> </div>    <div id="icebot6" class="icebot" style="display:none;height:300px;"><h2>Options</h2>
<h2 id="swtext" style="top:40px;left:10px;position:absolute;">Auto report &nbsp;</h2><label class="switch" style="top:10px;left:150px"><input type="checkbox" id="autoreport"><span class="slider round"></span></label>
<h2 id="swtext" style="top:80px;left:10px;position:absolute;">Auto skip &nbsp;</h2><label class="switch" style="top:16px;left:150px"><input type="checkbox" id="autoskip"><span class="slider round"></span></label>
<h2 id="swtext" style="top:120px;left:10px;position:absolute;">Anti kick &nbsp;</h2><label class="switch" style="top:22px;left:150px"><input type="checkbox" id="antikick"><span class="slider round"></span></label>
<h2 id="swtext" style="top:160px;left:10px;position:absolute;">Anti afk &nbsp;</h2><label class="switch" style="top:28px;left:150px"><input type="checkbox" id="antiafk"><span class="slider round"></span></label>
<h2 id="swtext" style="top:200px;left:10px;position:absolute;">Auto kick &nbsp;</h2><label class="switch" style="top:34px;left:150px"><input type="checkbox" id="autokick"><span class="slider round"></span></label>
<h2 id="swtext" style="top:240px;left:10px;position:absolute;">Auto farm &nbsp;</h2><label class="switch" style="top:40px;left:150px"><input type="checkbox" id="autofarm"><span class="slider round"></span></label>
<h2 id="swtext" style="top:280px;left:10px;position:absolute;">Auto guess &nbsp;</h2><label class="switch" style="top:46px;left:150px"><input type="checkbox" id="autoguess" onchange="window.postMessage('autoguess','*')"><span class="slider round"></span></label><h2 class="autoguessvalue" id="autoguessms" style="top:320px;position:absolute;"></h2><input class="autoguessrange" style="top:360px;left:60px;position:absolute;" type="range" oninput="postMessage('autoguess')" min="130" max="10000">
<h2 id="swtext" style="top:390px;left:10px;position:absolute;">Mimic mode &nbsp;</h2><label class="switch" style="top:120px;left:150px"><input type="checkbox" id="mimicmode" onchange="window.postMessage('mimicmode','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:430px;left:10px;position:absolute;">Rainbow draw &nbsp;</h2><label class="switch" style="top:126px;left:150px"><input type="checkbox" id="rainbowdraw" onchange="window.postMessage('rainbowdraw','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:470px;left:10px;position:absolute;">Give answer &nbsp;</h2><label class="switch" style="top:132px;left:150px"><input type="checkbox" id="giveanswer" onchange="window.postMessage('giveanswer','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:510px;left:10px;position:absolute;">Auto rejoin &nbsp;</h2><label class="switch" style="top:138px;left:150px"><input type="checkbox" id="autorejoin" onchange="window.postMessage('autorejoin','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:550px;left:10px;position:absolute;">Kick all (join) &nbsp;</h2><label class="switch" style="top:144px;left:150px"><input type="checkbox" id="kickalljoin" onchange="window.postMessage('kickalljoin','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:590px;left:10px;position:absolute;">Kick on join &nbsp;</h2><label class="switch" style="top:150px;left:150px"><input type="checkbox" id="kickonjoin" onchange="window.postMessage('kickonjoin','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:630px;left:10px;position:absolute;">All command &nbsp;</h2><label class="switch" style="top:156px;left:150px"><input type="checkbox" id="allcommand" onchange="window.postMessage('allcommand','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:670px;left:10px;position:absolute;">Auto tips &nbsp;</h2><label class="switch" style="top:162px;left:150px"><input type="checkbox" id="autotips" onchange="window.postMessage('autotips','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:710px;left:10px;position:absolute;">Join spam (3s)&nbsp;</h2><label class="switch" style="top:168px;left:150px"><input type="checkbox" id="joinspam" onchange="window.postMessage('joinspam','*')"><span class="slider round"></span></label>
<h2 style="top:870px;left:50px;position:absolute;">GUI theme color</h2>
    <input type="submit" style="top:900px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.red','*')" value="RED">
    <input type="submit" style="top:900px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.orange','*')" value="ORANGE">
    <input type="submit" style="top:940px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.yellow','*')" value="YELLOW">
    <input type="submit" style="top:940px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.green','*')" value="GREEN">
    <input type="submit" style="top:980px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.blue','*')" value="BLUE">
    <input type="submit" style="top:980px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.indigo','*')" value="INDIGO">
    <input type="submit" style="top:1020px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.violet','*')" value="VIOLET">
    <input type="submit" style="top:1020px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.pink','*')" value="PINK">
    <input type="submit" style="top:1060px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.crimson','*')" value="CRIMSON">
    <input type="submit" style="top:1060px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.brown','*')" value="BROWN">
    <input type="submit" style="top:1100px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.gray','*')" value="GRAY">
    <input type="submit" style="top:1100px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.white','*')" value="WHITE">
    <input type="submit" style="top:1140px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.black','*')" value="BLACK">
    <input type="submit" style="top:1140px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.magenta','*')" value="MAGENTA">
    <input type="submit" style="top:1180px;left:50px;position:absolute;" class="colorthemesbtn2" onclick="javascript:location.reload();localStorage.removeItem('theme')" value="RESET THEME">
    <h2 style="top:1220px;left:70px;position:absolute;">User options</h2>

<h2 id="swtext" style="top:1250px;left:10px;position:absolute;">Auto report &nbsp;</h2><label class="switch" style="top:675px;left:150px"><input type="checkbox" id="autoreportplayer" onchange="window.postMessage('autoreportp','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:1290px;left:10px;position:absolute;">Auto skip &nbsp;</h2><label class="switch" style="top:681px;left:150px"><input type="checkbox" id="autoskipplayer" onchange="window.postMessage('autoskipp','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:1330px;left:10px;position:absolute;">Anti kick &nbsp;</h2><label class="switch" style="top:687px;left:150px"><input type="checkbox" id="antikickplayer" onchange="window.postMessage('antikickp','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:1370px;left:10px;position:absolute;">Anti afk &nbsp;</h2><label class="switch" style="top:693px;left:150px"><input type="checkbox" id="antiafkplayer" onchange="window.postMessage('antiafkp','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:1410px;left:10px;position:absolute;">Auto kick &nbsp;</h2><label class="switch" style="top:699px;left:150px"><input type="checkbox" id="autokickplayer" onchange="window.postMessage('autokickp','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:1450px;left:10px;position:absolute;">Auto guess &nbsp;</h2><label class="switch" style="top:705px;left:150px"><input type="checkbox" id="autoguessplayer" onchange="window.postMessage('autoguessp','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:1490px;left:10px;position:absolute;">Give answer &nbsp;</h2><label class="switch" style="top:711px;left:150px"><input type="checkbox" id="giveanswerplayer" onchange="window.postMessage('giveanswerp','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:1530px;left:10px;position:absolute;">Auto tips&nbsp;</h2><label class="switch" style="top:717px;left:150px"><input type="checkbox" id="autotipsplayer" onchange="window.postMessage('autotipsp','*')"><span class="slider round"></span></label>
<h2 class="autoguessvalueplayer" id="autoguessmsplayer" style="top:1320px;position:absolute;"></h2><input class="autoguessrangeplayer" style="top:1285px;left:60px;position:absolute;" type="range" oninput="postMessage('autoguessplayer')" min="130" max="10000">
<input type="file" id="wordlist" style="top:1330px;left:50px;position:absolute;display:none;" onchange="window.postMessage('wordlist','*')" value="add new word list">
</div>
<div id="cavatarlist" class="icebot">    <input type="submit" class="hidecavatarlist" onclick="window.postMessage('hidecavatarlist','*')" value="CLOSE"><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/0.svg" class="selectedavatar" onclick="window.postMessage('cavt.0','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/1.svg" class="selectedavatar" onclick="window.postMessage('cavt.1','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/2.svg" class="selectedavatar" onclick="window.postMessage('cavt.2','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/3.svg" class="selectedavatar" onclick="window.postMessage('cavt.3','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/4.svg" class="selectedavatar" onclick="window.postMessage('cavt.4','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/5.svg" class="selectedavatar" onclick="window.postMessage('cavt.5','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/6.svg" class="selectedavatar" onclick="window.postMessage('cavt.6','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/7.svg" class="selectedavatar" onclick="window.postMessage('cavt.7','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/8.svg" class="selectedavatar" onclick="window.postMessage('cavt.8','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/9.svg" class="selectedavatar" onclick="window.postMessage('cavt.9','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/10.svg" class="selectedavatar" onclick="window.postMessage('cavt.10','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/11.svg" class="selectedavatar" onclick="window.postMessage('cavt.11','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/12.svg" class="selectedavatar" onclick="window.postMessage('cavt.12','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/13.svg" class="selectedavatar" onclick="window.postMessage('cavt.13','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/14.svg" class="selectedavatar" onclick="window.postMessage('cavt.14','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/15.svg" class="selectedavatar" onclick="window.postMessage('cavt.15','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/16.svg" class="selectedavatar" onclick="window.postMessage('cavt.16','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/17.svg" class="selectedavatar" onclick="window.postMessage('cavt.17','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/18.svg" class="selectedavatar" onclick="window.postMessage('cavt.18','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/19.svg" class="selectedavatar" onclick="window.postMessage('cavt.19','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/20.svg" class="selectedavatar" onclick="window.postMessage('cavt.20','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/21.svg" class="selectedavatar" onclick="window.postMessage('cavt.21','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/22.svg" class="selectedavatar" onclick="window.postMessage('cavt.22','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/23.svg" class="selectedavatar" onclick="window.postMessage('cavt.23','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/24.svg" class="selectedavatar" onclick="window.postMessage('cavt.24','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/25.svg" class="selectedavatar" onclick="window.postMessage('cavt.25','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/26.svg" class="selectedavatar" onclick="window.postMessage('cavt.26','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/27.svg" class="selectedavatar" onclick="window.postMessage('cavt.27','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/28.svg" class="selectedavatar" onclick="window.postMessage('cavt.28','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/29.svg" class="selectedavatar" onclick="window.postMessage('cavt.29','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/30.svg" class="selectedavatar" onclick="window.postMessage('cavt.30','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/31.svg" class="selectedavatar" onclick="window.postMessage('cavt.31','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/32.svg" class="selectedavatar" onclick="window.postMessage('cavt.32','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/33.svg" class="selectedavatar" onclick="window.postMessage('cavt.33','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/34.svg" class="selectedavatar" onclick="window.postMessage('cavt.34','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/35.svg" class="selectedavatar" onclick="window.postMessage('cavt.35','*')"></button></div><div class="avatarbtn"><button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/36.svg" class="selectedavatar" onclick="window.postMessage('cavt.36','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://garticphone.com/images/avatar/31.svg" class="selectedavatar" onclick="window.postMessage('cavt.null','*')"></button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/subjects/1.svg?v=1" class="selectedavatar" onclick="window.postMessage('cavt.random','*')"></button></div><br>    </div>  
    <div id="custombotnick" style="display:none;" class="icebot">    <img onclick="window.postMessage('customavatar','*')" id="cavatar" width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/`+localStorage.getItem("cavatar")+`.svg" ><div id="cstbtn" class="icebotbtn"><button onclick="window.postMessage('cnickclose','*')" style="width:15%;top:5px;left:5px;position:absolute;">CLOSE</button><button onclick="window.postMessage('cnickenable','*')" style="width:15%;top:5px;left:60px;position:absolute;">ENABLE</button><input type="text" id="customnick" maxlength="18" style="width:45%;" placeholder="Set custom nick here..."></input><button onclick="window.postMessage('customavatar','*')">AVATAR</button>&nbsp;&nbsp;&nbsp;&nbsp;<button onclick="window.postMessage('setcustomnick','*')" style="width:16%">SET</button>
</div></div>
<div class="icebot" id="icebot7" style="display:none;"><h2 class="msgjointext">Message when join</h2> 
<input type="text" placeholder="Message..." id="msgjoin" style="width:100%"></input><input type="submit" onclick="window.postMessage('msgjoin.broadcast','*')" style="width:33.3%" value="Broadcast"></input><input type="submit" onclick="window.postMessage('msgjoin.message','*')" style="width:33.3%" value="Message"></input><input type="submit" onclick="window.postMessage('msgjoin.answer','*')" style="width:33.3%" value="Answer"></input>
</div>
<div class="icebot" id="icebot8" style="display:none;"><h2 class="roomselectortext">Room selector</h2><select id="slctl" style="background-color:white"><optgroup label="Available Languages"><option value="23">Azərbaycanca</option><option value="45">Bahasa Indonesia</option><option value="11">Čeština</option><option value="14">Deutsch</option><option value="2">English</option><option value="3">Español</option><option value="4">Français</option><option value="6">Italiano</option><option value="44">Magyar</option><option value="18">Nederlands</option><option value="10">Polski</option><option value="1">Português</option><option value="58">Română</option><option value="22">Slovenčina</option><option value="13">Tiếng Việt</option><option value="8">Türkçe</option><option value="21">български език</option><option value="7">Русский</option><option value="40">עברית</option><option value="19">العربية</option><option value="34">فارسی</option><option value="12">ภาษาไทย</option><option value="16">中文 (简化字)</option><option value="9">中文 (臺灣)</option><option value="17">中文 (香港)</option><option value="15">日本語</option><option value="20">한국어</option></optgroup><select><select id="slctt" style="background-color:white"><optgroup label="Avaliable Themes"><option value="all">All themes</option><option value="30">Others / Generic</option><option value="1">General</option><option value="2">Animals</option><option value="28">Animes</option><option value="27">Bands</option><option value="9">Cartoons</option><option value="19">Clash Royale</option><option value="38">Crazy</option><option value="23">Dota</option><option value="22">Dragon Ball</option><option value="16">Flags</option><option value="33">FNAF</option><option value="4">Foods</option><option value="17">Football</option><option value="32">Fortnite</option><option value="21">Game of Thrones</option><option value="12">Games</option><option value="37">Halloween</option><option value="18">Harry Potter</option><option value="6">Jobs</option><option value="26">Logos</option><option value="11">LoL</option><option value="20">Lord of Rings</option><option value="14">Marvel / DC</option><option value="31">Minecraft</option><option value="8">Movies</option><option value="35">Naruto</option><option value="3">Objects</option><option value="13">Personalities</option><option value="7">Pokemon</option><option value="15">Series</option><option value="10">Songs</option><option value="29">Sports</option><option value="34">Star Wars</option><option value="25">Streamers</option><option value="36">The Sims</option><option value="5">Verbs</option><option value="24">Youtubers</option></optgroup></select><br><input type="submit" onclick="window.postMessage('roomsee','*')" style="width:60%" value="update"><div id="roomson"></div></div>

`);
let avataritem = localStorage.getItem("avatar");
if (!avataritem) {
  localStorage.setItem("avatar", 1);
  avatar=1
}
        if (avataritem=='null') {setTimeout(()=>{
f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";},1000)
                                }
        if (avataritem=='random') {setTimeout(()=>{
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";},1000)
                                }
                                
    let customkick = localStorage.getItem("customkick");
if (!customkick) {
  localStorage.setItem("customkick", "[]");
}

if (customkick) {
    let list=JSON.parse(localStorage.getItem("customkick"))

        list.forEach(user=>{
            setTimeout(()=>{
        f("#icebot4").innerHTML+=`<h2 class="customkick" id="customkick.`+user.user+`">`+user.user+`</h2>
    <input type="submit" class="customkickremove" id="customkickuser.`+user.user+`" onclick="window.postMessage('customkickremove.`+user.user+`','*')" value="remove">`

            },3000)
        })
}
     let botnickitem = localStorage.getItem("botnick");
if (!botnickitem) {
  localStorage.setItem("botnick", "0");
}
     let botsv = localStorage.getItem("bots");
if (!botsv) {
  localStorage.setItem("bots", '[{"link": "108.181.21.229"},{"link": "108.181.33.135"},{"link": "108.181.33.117"},{"link": "108.181.33.119"},{"link": "108.181.34.57"},{"link": "108.181.34.71"},{"link": "108.181.30.85"},{"link": "108.181.34.149"},{"link": "108.181.32.49"},{"link": "108.181.32.73"},{"link": "108.181.32.55"},{"link": "108.181.32.61"},{"link": "108.181.32.59"},{"link": "108.181.43.67"},{"link": "108.181.34.45"},{"link": "108.181.24.243"},{"link": "108.181.34.177"},{"link": "108.181.34.157"},{"link": "195.3.223.166"},{"link": "195.3.223.164"},{"link": "146.19.24.89"},{"link": "195.3.222.15"},{"link": "185.16.39.161"},{"link": "95.214.53.145"},{"link": "95.214.53.152"},{"link": "108.181.8.179"},{"link": "108.181.9.39"},{"link": "108.181.11.39"},{"link": "108.181.6.89"},{"link": "208.87.240.203"},{"link": "208.87.240.219"},{"link": "208.87.240.251"},{"link": "208.87.241.149"},{"link": "108.181.4.237"},{"link": "208.87.241.209"},{"link": "108.181.4.241"},{"link": "208.87.240.35"},{"link": "108.181.5.29"},{"link": "208.87.242.233"},{"link": "208.87.240.67"},{"link": "95.214.53.48"},{"link": "195.3.222.40"},{"link": "185.225.191.49"},{"link": "185.225.191.57"},{"link": "108.181.11.173"},{"link": "108.181.11.193"},{"link": "108.181.11.137"},{"link": "108.181.11.171"},{"link": "108.181.11.175"},{"link": "185.16.39.144"},{"link": "185.16.39.213"},{"link": "178.211.139.238"},{"link": "185.246.84.18"},{"link": "185.246.84.66"},{"link": "108.181.90.163"},{"link": "108.181.90.129"},{"link": "208.87.241.75"},{"link": "199.71.214.121"},{"link": "108.181.5.31"},{"link": "108.181.54.41"},{"link": "185.246.87.210"},{"link": "95.214.53.28"},{"link": "185.246.85.103"},{"link": "195.3.223.101"},{"link": "185.246.85.105"},{"link": "195.3.220.223"},{"link": "185.16.38.230"},{"link": "146.19.24.59"},{"link": "195.3.220.74"},{"link": "108.181.88.29"},{"link": "108.181.88.105"},{"link": "108.181.88.107"},{"link": "199.71.214.89"},{"link": "185.246.86.208"},{"link": "185.246.87.7"},{"link": "185.246.86.211"},{"link": "95.214.53.33"}]');
}
if(botsv){
	document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length
let botsp=JSON.parse(botsv);
	botsp.forEach(x=>{
	document.querySelector("#icebot5").innerHTML += `<input type="submit" style="width:100%; height:40px; position: relative; font-weight: bold;" id="proxy-`+x.link+`" onclick="window.postMessage('proxyrmv.`+x.link+`','*')" value="`+x.link+`">`;})
	}
	 let msgjoin = localStorage.getItem("messagejoin");
if (!msgjoin) {
  localStorage.setItem("messagejoin", "[]");
}

if (msgjoin) {
	let es=JSON.parse(msgjoin);
	es.forEach(d=>{
document.querySelector("#icebot7").innerHTML += `
<h2 class="msgjoinvalue" id="msgjoinvalue.${d.msg}">${d.type} : ${d.msg}</h2>
<input type="submit" class="msgjoinremove" id="msgjoin.${d.msg}" onclick="window.postMessage('messagejoinremove.${d.msg}','*')" value="remove">
`;})
  
}
	let cbotnickitems= localStorage.getItem("custom-nicks");
if (!cbotnickitems) {
  localStorage.setItem("custom-nicks", "[]");
}
if (cbotnickitems) {
	let xm=JSON.parse(cbotnickitems);
	xm.forEach(e=>{
	    	document.querySelector("#cstbtn").innerHTML += `
<button style="width:100%; height:60px;position: relative;" id="custom-`+e.nick+`" onclick="window.postMessage('cbtnrmv.`+e.nick+`','*')">
    <img width="50" height="50" style="position: absolute; left: 0; top: 0;" src="https://gartic.io/static/images/avatar/svg/`+e.avatar+`.svg">
    <span style="position: relative; top: -0px; left: 30px;">`+e.nick+`</span>
</button>
`;})
}
     let nickitem = localStorage.getItem("nick");
if (!nickitem) {
  localStorage.setItem("nick", "ICEbot");
}
     let quantitem = localStorage.getItem("quant");
if (!quantitem) {
  localStorage.setItem("quant", 15);
}
     let theme = localStorage.getItem("theme");
if (theme) {setTimeout(()=>{colorChanger(theme)},300)
}
     window.addEventListener("message",function(msg){
        if(typeof(msg.data)==="string"){
        	    if(msg.data=="hidemenu"){setmenu('none')}
    if(msg.data=="menu1"){setmenu('icebot1')}
    if(msg.data=="menu2"){setmenu('icebot2')}
    if(msg.data=="menu3"){setmenu('icebot3')}
    if(msg.data=="menu4"){setmenu('icebot4')}
    if(msg.data=="menu5"){setmenu('icebot5')}
    if(msg.data=="menu6"){setmenu('icebot6')}
    if(msg.data=="menu7"){setmenu('icebot7')}
    if(msg.data=="menu8"){setmenu('icebot8')}

    if(msg.data.indexOf("color.")!=-1){
 let color = event.data.split("color.")[1];localStorage.setItem("theme",color)
                colorChanger(color)
            }
                        if(msg.data=="quantbot"){
            localStorage.setItem("quant",f("#quantbot").value)

    }
            if(msg.data=="nick"){
            localStorage.setItem("nick",f("#botnick").value)

    }
        if(msg.data=="botnick0"){
botnick=0
localStorage.setItem("botnick",0)
}
if(msg.data=="botnick1"){
botnick=1
localStorage.setItem("botnick",1)
    }
    
if(msg.data=="botnick2"){
botnick=2
localStorage.setItem("botnick",2)
    }
    if(msg.data=="botnick3"){
botnick=4
localStorage.setItem("botnick",4)
    }
    if(msg.data=="botnick4"){
botnick=5
localStorage.setItem("botnick",5)
    }
    if(msg.data=="showavatarlist"){
        f("#icebot1").style.display="none"
        f("#avatarlist").style.display="block"
    }
    if(msg.data=="hideavatarlist"){
        f("#icebot1").style.display="block"
        f("#avatarlist").style.display="none"
    }
                if(msg.data.indexOf("proxyrmv.")!=-1){
 let proxym = msg.data.substring(9);
let storage = JSON.parse(localStorage.getItem("bots"));
if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].link === proxym) {
      storage.splice(i, 1);
          setTimeout(()=>{document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length},70)
      break;
    }
  }
  localStorage.setItem("bots", JSON.stringify(storage));
}
      let proxyel= document.getElementById("proxy-"+proxym)
      proxyel.remove()
            }

 if(msg.data.indexOf("avatar.")!=-1){
                let a=msg.data.split("avatar.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#avatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
avatar=a
localStorage.setItem("avatar",a)
    break;
    case 'null':

f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";
    avatar=null
localStorage.setItem("avatar",null)
break;
    case 'random':
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
    avatar='random'
localStorage.setItem("avatar",'random')
        break
            }}
                if(msg.data.indexOf("cavt.")!=-1){
                let a=msg.data.split("cavt.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#cavatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
localStorage.setItem("cavatar",a)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    break;
    case 'null':

f("#cavatar").src = "https://garticphone.com/images/avatar/31.svg";
localStorage.setItem("cavatar",null)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
break;
    case 'random':
f("#cavatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
localStorage.setItem("cavatar",'random')
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
        break
            }}
                if (msg.data === 'cnickenable') {
          	localStorage.setItem("botnick",3)
                	}
    if (msg.data === 'setcustomnick') {
    	let cavatar=parseInt(localStorage.getItem("cavatar"))
    	let cnick=document.querySelector("#customnick").value
let customnicks = JSON.parse(localStorage.getItem("custom-nicks")) || [];
if (!customnicks.some(i => i.nick === cnick)) {
    customnicks.push({
        avatar: cavatar,
        nick: cnick,
        isenabled: true
    });
    }
    localStorage.setItem('custom-nicks', JSON.stringify(customnicks));
    	document.querySelector("#cstbtn").innerHTML += `
<button style="width:100%; height:60px;position: relative;" id="custom-`+cnick+`" onclick="window.postMessage('cbtnrmv.`+cnick+`','*')">
    <img width="50" height="50" style="position: absolute; left: 0; top: 0;" src="https://gartic.io/static/images/avatar/svg/`+cavatar+`.svg">
    <span style="position: relative; top: -0px; left: 30px;">`+cnick+`</span>
</button>
`;
}
    	
        if (msg.data === 'customavatar') {
        	document.querySelector('#cavatarlist').style.display='block';document.querySelector('#custombotnick').style.display='none'
        	}
        
    if(msg.data=="hidecavatarlist"){
        	document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    }
        if(msg.data=="cnickclose"){
        	document.querySelector('#custombotnick').style.display='none';
    }
        if(msg.data=="cnickshow"){
        	document.querySelector('#custombotnick').style.display='block';
    }
                if(msg.data.indexOf("cbtnrmv.")!=-1){
                let abtn=msg.data.split("cbtnrmv.")[1]
                let storage = JSON.parse(localStorage.getItem("custom-nicks"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].nick === abtn) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("custom-nicks", JSON.stringify(storage));
 document.getElementById('custom-'+abtn).remove();
}
}
                if(msg.data=="getlocation"){var ifrm = document.createElement("iframe"); ifrm.setAttribute("src", "https://croxyproxy.rocks/?proxyset"); ifrm.style.width = "100px"; ifrm.style.height = "180px";ifrm.style.display = "none"; document.body.appendChild(ifrm);var ifrm2 = document.createElement("iframe"); ifrm2.setAttribute("src", "https://proxyium.com/?2proxyset"); ifrm2.style.width = "100px"; ifrm2.style.height = "180px";ifrm2.style.display = "none"; document.body.appendChild(ifrm2);
                setTimeout(()=>{
     window.postMessage('proxyactive','*');
                	},10000)
}
                if(msg.data=="refreshall"){
             let bx = localStorage.getItem("bots");
             let ba = JSON.parse(bx);
             
let bots = ba.filter(item => ![
        {link: "185.246.87.210"},
        {link: "95.214.53.28"},
        {link: "185.246.85.103"},
        {link: "195.3.223.101"},
        {link: "185.246.85.105"},
        {link: "195.3.220.223"},
        {link: "185.16.38.230"},
        {link: "146.19.24.59"},
        {link: "195.3.220.74"}
    ].find(obj => obj.link === item.link)
);

let bots2 = ba.filter(item => [
    {link: "185.246.87.210"},
    {link: "95.214.53.28"},
    {link: "185.246.85.103"},
    {link: "195.3.223.101"},
    {link: "185.246.85.105"},
    {link: "195.3.220.223"},
    {link: "185.16.38.230"},
    {link: "146.19.24.59"},
    {link: "195.3.220.74"}
].find(obj => obj.link === item.link));

chrome.storage.local.get("locationValue2",function(e){let lc=e.locationValue2
bots2.forEach(b=>{fetch("https://"+b.link+"/"+lc, {
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
})})})
chrome.storage.local.get("locationValue",function(e){let lc=e.locationValue
bots.forEach(b=>{fetch("https://"+b.link+"/"+lc, {
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
})})});
}
        if(msg.data=="autoguess"){
        let autoguessMS=f(".autoguessrange").value
        f("#autoguessms").innerText='AUTO GUESS VALUE: ' + autoguessMS
        localStorage.setItem("autoguess",autoguessMS)
        }
                if(msg.data=="mimicmode"){if(document.querySelector("#mimicmode").checked){localStorage.setItem("mimic",'true')} else {localStorage.setItem("mimic",'false') }}
                                if(msg.data.indexOf("reportone.")!=-1){
 let id = event.data.split("reportone.")[1];
__0x70("reportone",id)
            }
                if(msg.data.indexOf("kickuser.")!=-1){
 let id = event.data.split("kickuser.")[1];
 __0x70("kick",id)
            }
if(msg.data=="broadcast"){
__0x70("broadcast",document.querySelector("#broadcast").value)
        }
if(msg.data=="broadcastspam"){
__0x70("broadcastspam",document.querySelector("#broadcast").value)
        }
        if(msg.data=="chat"){
__0x70("msg",document.querySelector("#message").value)
        }
 if(msg.data.indexOf("chatx.")!=-1){
                let a=msg.data.split("chatx.")[1]
__0x70("msg",a)
        }
        if(msg.data=="chatspam"){
__0x70("msgspam",document.querySelector("#message").value)
        }
        if(msg.data=="answer"){
__0x70("answer",document.querySelector("#answer").value)
        }
 if(msg.data.indexOf("answerx.")!=-1){
                let a=msg.data.split("answerx.")[1]
__0x70("answer",a)
        }
        if(msg.data=="answerspam"){
__0x70("answerspam",document.querySelector("#answer").value)
        }
                    if(msg.data=="broadcastspamtoggle"){
            let broadcastspamMS=parseInt(localStorage.getItem("broadcastspam"))
            var broadcastspam = document.querySelector("#broadcastspam").value
            intervalbroadcast=setInterval(()=>{
                __0x70("broadcastspam",broadcastspam)
            },broadcastspamMS)
        document.querySelector("#broadcaststart").style.display="none"
        document.querySelector("#broadcaststop").style.display="block"
        }
        if(msg.data=="chatspamtoggle"){
            let messagespamMS=parseInt(localStorage.getItem("messagespam"))
            var messagespam = document.querySelector("#messagespam").value
            intervalmsg=setInterval(()=>{
            var chatspam = document.querySelector("#messagespam").value
                __0x70("msgspam",chatspam)
            },messagespamMS)
        document.querySelector("#msgstart").style.display="none"
        document.querySelector("#msgstop").style.display="block"
        }
        if(msg.data=="answerspamtoggle"){
            let answerspamMS=parseInt(localStorage.getItem("answerspam"))
            var answerspam = document.querySelector("#answerspam").value
            intervalanswer=setInterval(()=>{
            var answerspam = document.querySelector("#answerspam").value
                __0x70("answerspam",answerspam)
            },answerspamMS)
        document.querySelector("#answerstart").style.display="none"
        document.querySelector("#answerstop").style.display="block"
        }
        if(msg.data=="stopbroadcast"){
        clearInterval(intervalbroadcast)
        document.querySelector("#broadcaststart").style.display="block"
        document.querySelector("#broadcaststop").style.display="none"
        }
        if(msg.data=="stopmsg"){
        clearInterval(intervalmsg)
        document.querySelector("#msgstart").style.display="block"
        document.querySelector("#msgstop").style.display="none"
        }
        if(msg.data=="stopanswer"){
        clearInterval(intervalanswer)
        document.querySelector("#answerstart").style.display="block"
        document.querySelector("#answerstop").style.display="none"
        }
             if(msg.data=="broadcastspam"){
        let broadcastspamMS=document.querySelector(".broadcastspam").value
        f("#broadcastms").innerText='BROADCAST SPAM VALUE: ' + broadcastspamMS
        localStorage.setItem("broadcastspam",broadcastspamMS)
    }
    if(msg.data=="messagespam"){
        let messagespamMS=document.querySelector(".messagespam").value
        f("#messagems").innerText='MESSAGE SPAM VALUE: ' + messagespamMS
        localStorage.setItem("messagespam",messagespamMS)
    }
    if(msg.data=="answerspam"){
        let answerspamMS=document.querySelector(".answerspam").value
        f("#answerms").innerText='ANSWER SPAM VALUE: ' + answerspamMS
        localStorage.setItem("answerspam",answerspamMS)
    }
      if(msg.data=="customkickadd"){
 const value = f("#kicklistinput").value;
var customkicklist = localStorage.getItem("customkick");

  let customkickitem = JSON.parse(localStorage.getItem("customkick"));
  if (customkickitem.findIndex(item => item.user === value) === -1) {
    customkickitem.push({ "user": value });
    localStorage.setItem("customkick", JSON.stringify(customkickitem));
    f("#icebot4").innerHTML += `<h2 class="customkick" id="customkick.` + value + `">` + value + `</h2>
    <input type="submit" class="customkickremove" id="customkickuser.` + value + `" onclick="window.postMessage('customkickremove.` + value + `','*')" value="remove"></input>`
  }

        }
                    if(msg.data.indexOf("customkickremove.")!=-1){
 let usernick = event.data.split("customkickremove.")[1];
let storage = JSON.parse(localStorage.getItem("customkick"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].user === usernick) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("customkick", JSON.stringify(storage));
      let kickusertext= document.getElementById("customkick."+usernick)
      let kickuserremovebtn= document.getElementById("customkickuser."+usernick)
      kickusertext.remove()
      kickuserremovebtn.remove()
}}
        if(msg.data=="customkickremoveall"){
var elementsCustomKick = document.querySelectorAll('[id*="customkick."]');
var elementsCustomKickUser = document.querySelectorAll('[id*="customkickuser."]');
function deleteElement(element) {
  element.parentNode.removeChild(element);
}
elementsCustomKick.forEach(function(element) {
  deleteElement(element);
});
elementsCustomKickUser.forEach(function(element) {
  deleteElement(element);

})
      localStorage.setItem("customkick","[]")
      
        }
    if(msg.data.indexOf("msgjoin.")!=-1){ 	
                let xmd=msg.data.split("msgjoin.")[1]
 const value = document.querySelector("#msgjoin").value;
var messagelist = localStorage.getItem("messagejoin");

  let custommsgitem = JSON.parse(localStorage.getItem("messagejoin"));

    custommsgitem.push({ "msg": value ,"type":xmd});
    localStorage.setItem("messagejoin", JSON.stringify(custommsgitem));
document.querySelector("#icebot7").innerHTML += `
<h2 class="msgjoinvalue" id="msgjoinvalue.${value}">${xmd} : ${value}</h2>
<input type="submit" class="msgjoinremove" id="msgjoin.${value}" onclick="window.postMessage('messagejoinremove.${value}','*')" value="remove">
`;
  

    }
      if(msg.data.indexOf("messagejoinremove.")!=-1){
 let message = msg.data.split("messagejoinremove.")[1];
let storage = JSON.parse(localStorage.getItem("messagejoin"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].msg === message) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("messagejoin", JSON.stringify(storage));
}
      let msgjointext= document.getElementById("msgjoinvalue."+message)
      let msgjoinremovebtn= document.getElementById("msgjoin."+message)
      msgjointext.remove()
      msgjoinremovebtn.remove()

       }
   if(msg.data=="dupejoin"){window.postMessage('join','*');fetch("https://gartic.io/favicon.ico?rjoin=1")}
    if(msg.data=="join"){__0x70("join",document.querySelector("#roomlink").value.split("/")[3],document.querySelector("#botnick").value,avatar,localStorage.getItem("botnick"),localStorage.getItem("custom-nicks"),localStorage.getItem("messagejoin"),parseInt(localStorage.getItem("combining")))

}
    if(msg.data=="exit"){__0x70("exit")}
    if(msg.data=="report"){__0x70("report");}
    if(msg.data=="jump"){__0x70("jump")}
    if(msg.data=="0xbE"){__0x70("0xbE")}
    if(msg.data=="afkconfirm"){__0x70("afkconfirm")}
    if(msg.data=="acceptdraw1"){__0x70("accept1")}
    if(msg.data=="acceptdraw2"){__0x70("accept2")}
    if(msg.data=="tips"){__0x70("tips")}
}})
        document.querySelector(".kickallwhenjoin").addEventListener("click",()=>{__0x70("kicknewset",f(".kickallwhenjoin").checked)})
        document.querySelector(".kickonjoin").addEventListener("click",()=>{__0x70("kickjoinset",f(".kickonjoin").checked)
        })
                document.querySelector("#autoreport").addEventListener("click",()=>{__0x70("autoreport",f("#autoreport").checked);
        })
                document.querySelector("#autoskip").addEventListener("click",()=>{__0x70("autoskip",f("#autoskip").checked)
        })
                document.querySelector("#antikick").addEventListener("click",()=>{__0x70("antikick",f("#antikick").checked)
        })
                document.querySelector("#autokick").addEventListener("click",()=>{__0x70("autokick",f("#autokick").checked)
        })
                document.querySelector("#antiafk").addEventListener("click",()=>{__0x70("antiafk",f("#antiafk").checked)
        })
                document.querySelector("#autofarm").addEventListener("click",()=>{__0x70("autofarm",f("#autofarm").checked)
        })
                document.querySelector("#autoguess").addEventListener("click",()=>{__0x70("autoguess",f("#autoguess").checked)
        })
        
                document.querySelector("#giveanswer").addEventListener("click",()=>{__0x70("giveanswer",f("#giveanswer").checked)
        })
        
                document.querySelector("#autorejoin").addEventListener("click",()=>{__0x70("autorejoin",f("#autorejoin").checked)
        })
        
                document.querySelector("#kickalljoin").addEventListener("click",()=>{__0x70("kickalljoin",f("#kickalljoin").checked)
        })
                        document.querySelector("#kickonjoin").addEventListener("click",()=>{__0x70("kickonjoin",f("#kickonjoin").checked)
        })               
 document.querySelector("#allcommand").addEventListener("click",()=>{__0x70("allcommand",f("#allcommand").checked)
        })
 document.querySelector("#autotips").addEventListener("click",()=>{__0x70("autotips",f("#autotips").checked)
        })
                    	    let kicknewstat=false,kickjoinstat=false,autoreport=false,autoskip=false,antiafk=false,antikick=false,antikickDelay=1,autokick=false,autoguess,autofarm=false,giveanswer=false,autorejoin=false,kickalljoin=false,kickonjoin=false,allcommand=false,autotips=false,waitforkick=0
function rnext(kelime) { const hd = kelime.split(''); const hu = hd.length; const yh = []; const invisibleChars = ['\u200B', '\u200C', '\u200D', '\u2061', '\u2062', '\u2063', '\u2064', '\u2066', '\u17b4', '\u17b5', '\u2068', '\u2069']; let charCount = 0; for (let i = 0; i < hu; i++) {yh.push(hd[i]);charCount++;if (charCount < 18 && i < hu - 1) { const invisibleChar = invisibleChars[Math.floor(Math.random() * invisibleChars.length)]; yh.push(invisibleChar); charCount++;}if (charCount >= 18) { break;} } return yh.join('');}
function LUNA(o, pN, c) {let v = o[pN];Object.defineProperty(o, pN, {  get() { return v;    },set(nV) {  if (nV !== v) {  const oV = v;  v = nV; c(nV, oV);    }},  });};
let usersinroom=[]
         let lE=JSON.parse(localStorage.getItem("languages"));
let sE=JSON.parse(localStorage.getItem("subjects"));let arfSL=[];function gSL(s, l) {const sO=sE.find(item => item.id === s);const lO= lE.find(item => item.id === l);if(sO && lO) {arfSL=[sO.name,lO.name];}}
const data = {ev: 10};
function g(e, x) {
  data.ev = [e,x,Math.ceil(Math.random()*100000+1)]
}
     let inv= ['឴','‏','឵','­','͏','‎','𝅹','⁡'];
     
function aT(m, n) {
  let cC = "";  switch(n) {
case 1: cC="\u0300"; break;
case 2: cC="\u0301"; break;
case 3: cC="\u0302"; break;
case 4: cC="\u0303"; break; 
case 5: cC="\u0304"; break; 
case 6: cC="\u0305"; break; 
case 7: cC="\u0306"; break; 
case 8: cC="\u0307"; break;
case 9: cC="\u0308"; break; 
case 10: cC="\u0309"; break; 
case 11: cC="\u030a"; break; 
case 12: cC="\u030b"; break; 
case 13: cC="\u030c"; break; 
case 14: cC="\u030d"; break; 
case 15: cC="\u030e"; break; 
case 16: cC="\u030f"; break;
case 17: cC="\u0310"; break; 
case 18: cC="\u0311"; break; 
case 19: cC="\u0312"; break; 
case 20: cC="\u0313"; break; 
case 21: cC="\u0314"; break; 
case 22: cC="\u0315"; break; 
case 23: cC="\u0316"; break; 
case 24: cC="\u0317"; break;
case 25: cC="\u0318"; break; 
case 26: cC="\u0319"; break; 
case 27: cC="\u031a"; break; 
case 28: cC="\u031b"; break; 
case 29: cC="\u031c"; break; 
case 30: cC="\u031d"; break; 
case 31: cC="\u031e"; break; 
case 32: cC="\u031f"; break;
case 33: cC="\u0320"; break; 
case 34: cC="\u0321"; break; 
case 35: cC="\u0322"; break; 
case 36: cC="\u0323"; break; 
case 37: cC="\u0324"; break; 
case 38: cC="\u0325"; break; 
case 39: cC="\u0326"; break; 
case 40: cC="\u0327"; break;
case 41: cC="\u0328"; break; 
case 42: cC="\u0329"; break; 
case 43: cC="\u032a"; break; 
case 44: cC="\u032b"; break; 
case 45: cC="\u032c"; break; 
case 46: cC="\u032d"; break; 
case 47: cC="\u032e"; break; 
case 48: cC="\u032f"; break;
case 49: cC="\u0330"; break; 
case 50: cC="\u0331"; break; 
case 51: cC="\u0332"; break; 
case 52: cC="\u0333"; break; 
case 53: cC="\u0334"; break; 
case 54: cC="\u0335"; break; 
case 55: cC="\u0336"; break; 
case 56: cC="\u0337"; break;
case 57: cC="\u0338"; break; 
case 58: cC="\u0339"; break; 
case 59: cC="\u033a"; break; 
case 60: cC="\u033b"; break; 
case 61: cC="\u033c"; break; 
case 62: cC="\u033d"; break; 
case 63: cC="\u033e"; break; 
case 64: cC="\u033f"; break;
case 65: cC="\u0340"; break; 
case 66: cC="\u0341"; break; 
case 67: cC="\u0342"; break; 
case 68: cC="\u0343"; break; 
case 69: cC="\u0344"; break; 
case 70: cC="\u0345"; break; 
case 71: cC="\u0346"; break; 
case 72: cC="\u0347"; break;
case 73: cC="\u0348"; break; 
case 74: cC="\u0349"; break; 
case 75: cC="\u034a"; break; 
case 76: cC="\u034b"; break; 
case 77: cC="\u034c"; break; 
case 78: cC="\u034d"; break; 
case 79: cC="\u034e"; break; 
case 80: cC="\u034f"; break;
case 81: cC="\u0350"; break; 
case 82: cC="\u0351"; break; 
case 83: cC="\u0352"; break; 
case 84: cC="\u0353"; break; 
case 85: cC="\u0354"; break; 
case 86: cC="\u0355"; break; 
case 87: cC="\u0356"; break; 
case 88: cC="\u0357"; break;
case 89: cC="\u0358"; break; 
case 90: cC="\u0359"; break; 
case 91: cC="\u035a"; break; 
case 92: cC="\u035b"; break; 
case 93: cC="\u035c"; break; 
case 94: cC="\u035d"; break; 
case 95: cC="\u035e"; break; 
case 96: cC="\u035f"; break;
case 97: cC="\u0360"; break; 
case 98: cC="\u0361"; break; 
case 99: cC="\u0362"; break; 
case 100: cC="\u0363"; break; 
case 101: cC="\u0364"; break; 
case 102: cC="\u0365"; break; 
case 103: cC="\u0366"; break; 
case 104: cC="\u0367"; break;
case 105: cC="\u0368"; break; 
case 106: cC="\u0369"; break; 
case 107: cC="\u036a"; break; 
case 108: cC="\u036b"; break; 
case 109: cC="\u036c"; break; 
case 110: cC="\u036d"; break; 
case 111: cC="\u036e"; break; 
case 112: cC="\u036f"; break;
  } let nT = "";for (let i = 0; i < m.length; i++) {if (m[i] !== " ") {nT += m[i] + cC;} else {nT += m[i];}} return nT;}
     function em(p){
  let iC = ['\uFE00', '\uFE01', '\uFE02', '\uFE03', '\uFE04', '\uFE05', '\uFE06', '\uFE07', '\uFE08', '\uFE09', '\uFE0A', '\uFE0B', '\uFE0C', '\uFE0D', '\uFE0E', '\uFE0F','\u206F','\u206E','\u200B', '\u200C', '\u200D', '\u2061', '\u2062', '\u2063', '\u2064', '\u2066', '\u17b4', '\u17b5', '\u2068', '\u2069'];
  let niC = 18 - p.length;  
  for(let i = 0; i < niC; i++){
    let rP = Math.floor(Math.random() * p.length);
    let rC = iC[Math.floor(Math.random() * iC.length)];   
    p = p.slice(0, rP) + rC + p.slice(rP);
  }  
  return p;
};
function gRc() { const eR = [128512, 128591, 128640, 128767, 129280, 129535];  let c; do {
    c = Math.floor(Math.random() * 2801);
  } while (eR.some(range => c >= range && c <= range + 127));  return c;}
function gRcs() {const cs = [];for (let i = 0; i < 17; i++) {  cs.push(String.fromCharCode(gRc())); } return cs;}
   let etL = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
function shuffle(a) {for (let i = a.length - 1; i > 0; i--) {let j = Math.floor(Math.random() * (i + 1));[a[i], a[j]] = [a[j], a[i]];}  return a;}
const intervalIds= {};
  const webSockets = {};
window.addEventListener('message', function(event) {
    if(event.data.startsWith("cmd.")){
	          let abtn=event.data.split("cmd.")[1];
	let nv=JSON.parse(abtn);console.log(nv);console.log(abtn);
    	switch(nv[0]){
    	case "join":
   let room=nv[1];
   ws__.send(JSON.stringify({"cmd":'["join","'+room+'","ICEbot","1","2","[]","[]",null,"'+document.querySelector("#quantbot").value+'"]'}))
break;
case "broadcast":let b=nv[1];ws__.send(JSON.stringify({"cmd":'["broadcast","'+b+'"]'}));break;
case "broadcastspam":let be=nv[1];g('broadcastspam',be);break;
case "msg":let m=nv[1];ws__.send(JSON.stringify({"cmd":'["msg","'+m+'"]'}));break;
case "msgspam":let me=nv[1];g('msgspam',me);break;
case "answer":let a=nv[1];ws__.send(JSON.stringify({"cmd":'["answer","'+a+'"]'}));break;
case "answerspam":let ae=nv[1];g('answerspam',ae);break;
case "exit":ws__.send(JSON.stringify({"cmd":'["exit"]'}));break;
case "report":ws__.send(JSON.stringify({"cmd":'["report"]'}));break;
case "reportone":g('reportone',nv[1]);break;
case "0xbE":g('0xbE','1');break;
case "jump":ws__.send(JSON.stringify({"cmd":'["jump"]'}));break;
case "tips":ws__.send(JSON.stringify({"cmd":'["tips"]'}));break;
case "accept1":g('accept1','1');break;
case "accept2":g('accept2','1');break;
case "kick":let k=nv[1];ws__.send(JSON.stringify({"cmd":'["kick","'+k+'"]'}));break;
case "rejoin":g('rejoin','1');break;
case "afkconfirm":g('afkconfirm','1');break;
case "kicknewset":break;
case "kickjoinset":break;
case "autoreport":autoreport=nv[1];break;
case "autoskip":autoskip=nv[1];break;
case "antikick":antikick=nv[1];break;
case "autokick":autokick=nv[1];break;
case "antiafk":antiafk=nv[1];if(nv[1]===true){intervalantiafk = setInterval(()=> {g('afkconfirm','1'); }, 10000);} else {clearInterval(intervalantiafk);}break;
case "autofarm":autofarm=nv[1];break;
case "autoguess":autoguess=nv[1];break;
case "giveanswer":giveanswer=nv[1];break;
case "autorejoin":autorejoin=nv[1];break;
case "kickalljoin":kickalljoin=nv[1];break;
case "kickonjoin":kickonjoin=nv[1];break;
case "allcommand":allcommand=nv[1];break;
case "autotips":autotips=nv[1];break;
  
      
  
      
    
  }
}});
if(botsv!=="[]" && 1==2){
setTimeout(()=>{let obj=JSON.parse(localStorage.getItem("bots")); obj.forEach(links=>{var ifrm = document.createElement("iframe"); ifrm.setAttribute("src", "https://"+links.link+"/favicon.ico?__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8"); ifrm.style.width = "100px"; ifrm.style.height = "180px";ifrm.style.display = "none"; document.body.appendChild(ifrm);})},1000)}

chrome.storage.onChanged.addListener(function(changes, namespace) {
  if (changes.message) {
    let ne = changes.message.newValue;
    let nv = JSON.parse(ne)
    switch(nv[0]){
    	case "nextURL":
            let obj=JSON.parse(localStorage.getItem("bots"))
        localStorage.getItem("bots").indexOf(nv[1])==-1?obj.push({"link":nv[1],"timestamp":new Date().getTime()}):0
        
        localStorage.getItem("bots").indexOf(nv[1])==-1?document.querySelector("#icebot5").innerHTML += `<input type="submit" style="width:100%; height:40px; position: relative; font-weight: bold;" id="proxy-`+nv[1]+`" onclick="window.postMessage('proxyrmv.`+nv[1]+`','*')" value="`+nv[1]+`">`:0
        localStorage.setItem("bots",JSON.stringify(obj))        
    document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length;


    break;
    case "answerinput":
    document.querySelector('#answer').value=nv[1]
    break;
    case "word1":
        document.querySelector('#word1').value=nv[1]
    break;
    case "word2":
        document.querySelector('#word2').value=nv[1]
    break;
    case "answer":
    __0x70("answer",nv[1])
    break;
    case "kick":
    __0x70("kick",nv[1])
    break;
    case "rejoin":
    __0x52("join",nv[1],nv[2],nv[3],nv[4],nv[5])
    break;
    case "callbackbot":
    setTimeout(()=>{window.postMessage('colorbot.'+nv[1],'*')},60)
    break;
    }
  }
});

function injectScript (src) { const s = document.createElement('script'); s.src = chrome.runtime.getURL(src); s.type = "module";
 s.onload = () => s.remove(); (document.head || document.documentElement).append(s); }
function is2 (src) { const s = document.createElement('script'); s.src = chrome.runtime.getURL(src);
 (document.head || document.documentElement).append(s); } injectScript('wsProxy.js');is2('sweetalert2@10.js');
        	}

if(window.location.href.indexOf("?__cpo=")!=-1){
    LUNA_("nextURL",window.location.href.split("/")[2])
    setTimeout(()=>{
window.close();},5000)
}

if(window.location.href.indexOf("?proxyset")!=-1){setTimeout(()=>{
document.querySelector("#quickLinks > a:nth-child(1)").setAttribute("data-href","https://gartic.io/favicon.ico")
setInterval(()=>{
    document.querySelector("#quickLinks > a:nth-child(1)").click()},1)},1000)}
    if(window.location.href.indexOf("?2proxyset")!=-1){setTimeout(()=>{
document.querySelector("#unique-form-control").value="https://gartic.io/favicon.ico";setTimeout(()=>{document.querySelector("#unique-btn-blue").click()},200)},1000)}